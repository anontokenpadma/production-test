--  Wire protocol parsing and reply building. Fully in SPARK.
--  All line inputs must be normalized (First = 1) by the caller.
package Tedex_Protocol with SPARK_Mode is

   Max_Name : constant := 64;
   Max_Pass : constant := 128;
   Max_Dev  : constant := 64;
   Max_Line : constant := 2048;

   type Auth_Kind is (Auth_Bad, Auth_Device, Auth_Manager);

   type Auth_Request is record
      Kind     : Auth_Kind := Auth_Bad;
      User     : String (1 .. Max_Name) := [others => ' '];
      User_Len : Natural range 0 .. Max_Name := 0;
      Pass     : String (1 .. Max_Pass) := [others => ' '];
      Pass_Len : Natural range 0 .. Max_Pass := 0;
      Dev      : String (1 .. Max_Dev) := [others => ' '];
      Dev_Len  : Natural range 0 .. Max_Dev := 0;
   end record;

   function Is_Hex_Char (C : Character) return Boolean
     with Post => Is_Hex_Char'Result =
                    (C in '0' .. '9' or C in 'a' .. 'f'
                     or C in 'A' .. 'F'),
          Global => null,
          Depends => (Is_Hex_Char'Result => C);

   --  Parse "AUTH <device|manager> <user> <password> <device_id|->".
   --  Boundary obligation: caller must normalize Line to First = 1
   --  (Tedex_Net.Recv_Line / Ws_Recv_Line already do this).
   procedure Parse_Auth (Line : String; Req : out Auth_Request)
     with Pre => Line'First = 1 and Line'Length <= Max_Line,
          Global => null,
          Depends => (Req => Line);

   type Manager_Cmd is
     (Cmd_List, Cmd_Attach, Cmd_Remove, Cmd_Quit, Cmd_Bad);

   --  Parse "LIST" | "QUIT" | "EXIT" | "ATTACH <id>" | "REMOVE <id>".
   --  Boundary obligation: caller must normalize Line to First = 1.
   procedure Parse_Command (Line    : String;
                            Cmd     : out Manager_Cmd;
                            Arg     : out String;
                            Arg_Len : out Natural)
     with Pre  => Line'First = 1 and Line'Length <= Max_Line
                  and Arg'First = 1 and Arg'Length >= Max_Dev,
          Post => Arg_Len <= Max_Dev and Arg_Len <= Arg'Length,
          Global => null,
          Depends => (Cmd => Line, Arg =>+ Line, Arg_Len => Line);

   --  Decimal image, no leading space.
   function Nat_Image (N : Natural) return String
     with Pre  => N <= 999_999,
          Post => Nat_Image'Result'Length in 1 .. 6,
          Global => null,
          Depends => (Nat_Image'Result => N);

   function Devices_Header (N : Natural) return String
     with Pre  => N <= 999_999,
          Post => Devices_Header'Result'Length <= 14,
          Global => null,
          Depends => (Devices_Header'Result => N);

   function Devices_Allowed (Active_Count, Limit : Natural) return Boolean
     with Post => Devices_Allowed'Result = (Active_Count < Limit),
          Global => null,
          Depends => (Devices_Allowed'Result => (Active_Count, Limit));

   function Is_Token_Char (C : Character) return Boolean
     with Post => Is_Token_Char'Result =
                    (C in 'a' .. 'z' or C in 'A' .. 'Z'
                     or C in '0' .. '9' or C = '_' or C = '-' or C = '.'),
          Global => null,
          Depends => (Is_Token_Char'Result => C);

   --  Shared account/device identifier check (1..64, alnum _ - .).
   --  Total function: usable from boundary units without precondition.
   function Valid_Token (S : String) return Boolean
     with Post => Valid_Token'Result =
                   (S'Length in 1 .. Max_Name
                    and (for all C of S => Is_Token_Char (C))),
          Global => null,
          Depends => (Valid_Token'Result => S);

   --  Optional "SHELL_START <cols> <rows>" suffix (server to device).
   --  0,0 means plain "SHELL_START" or anything malformed: the caller
   --  keeps its spawn default. Boundary obligation: Line normalized.
   procedure Parse_Start_Dims (Line : String; Cols, Rows : out Natural)
     with Pre  => Line'First = 1 and Line'Length <= Max_Line,
          Post => Cols <= 1000 and Rows <= 1000
                  and ((Cols = 0) = (Rows = 0)),
          Global => null,
          Depends => ((Cols, Rows) => Line);

   --  Parse "RESIZE <dev> <cols> <rows>" (manager to server). Blank is
   --  space or HT. Ok is False (with zeroed outputs) on any shape,
   --  token or range violation. Boundary obligation: Line normalized.
   procedure Parse_Resize (Line    : String;
                           Dev     : out String;
                           Dev_Len : out Natural;
                           Cols    : out Natural;
                           Rows    : out Natural;
                           Ok      : out Boolean)
     with Pre  => Line'First = 1 and Line'Length <= Max_Line
                  and Dev'First = 1 and Dev'Length >= Max_Dev,
          Post => (if Ok then Dev_Len in 1 .. Max_Dev
                               and Dev_Len <= Dev'Length
                               and Cols in 1 .. 1000
                               and Rows in 1 .. 1000
                               and Valid_Token
                                     (Dev (Dev'First
                                           .. Dev'First + Dev_Len - 1))
                   else Dev_Len = 0 and Cols = 0 and Rows = 0),
          Global => null,
          Depends => (Dev                         => (Line, Dev),
                      (Dev_Len, Cols, Rows, Ok) => (Line, Dev));

   --  Reconnect backoff base in seconds for Failures consecutive
   --  failures (must be >= 1): 5, 10, 20, 40, then capped at 60.
   --  Callers add a few seconds of jitter on top. Total function.
   function Backoff_Secs (Failures : Natural) return Natural
     with Pre  => Failures >= 1,
          Post => Backoff_Secs'Result in 5 .. 60,
          Global => null,
          Depends => (Backoff_Secs'Result => Failures);

end Tedex_Protocol;
