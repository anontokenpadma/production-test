with System;
with Tedex_Tls;

package body Tedex_Shell with SPARK_Mode => Off is

   function C_Spawn (Master, Pid : access Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "pty_spawn_bash";

   function C_Poll (Master, Pid : Interfaces.C.int;
                    Buf         : System.Address;
                    Max         : Interfaces.C.int;
                    Timeout_Ms  : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "pty_poll";

   function C_Close (Master, Pid : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "pty_close";

   procedure Spawn (H : out Handle) is
      M, P  : aliased Interfaces.C.int;
      Rc    : Interfaces.C.int;
   begin
      H.Open := False;
      H.Master := -1;
      H.Pid := -1;
      Rc := C_Spawn (M'Access, P'Access);
      if Rc /= 0 then
         raise Shell_Error with "spawn failed";
      end if;
      H.Master := M;
      H.Pid := P;
      H.Open := True;
   end Spawn;

   procedure Send (H : in out Handle; Data : String) is
      Rc : Interfaces.C.int;
   begin
      if not H.Open then
         raise Shell_Error with "closed";
      end if;
      if Data'Length = 0 then
         return;
      end if;
      Rc := Tedex_Tls.Fd_Write_All (H.Master, Data'Address,
                                    Interfaces.C.int (Data'Length));
      if Rc /= 0 then
         raise Shell_Error with "closed";
      end if;
   end Send;

   function Poll (H : in out Handle; Timeout_Ms : Natural := 1) return String is
      Buf : aliased String (1 .. 32_768);
      Rc  : Interfaces.C.int;
   begin
      if not H.Open then
         raise Shell_Error with "closed";
      end if;
      Rc := C_Poll (H.Master, H.Pid, Buf'Address, Buf'Length,
                    Interfaces.C.int (Timeout_Ms));
      if Rc > 0 then
         return Buf (1 .. Natural (Rc));
      elsif Rc = 0 then
         return "";
      else
         raise Shell_Error with "closed";
      end if;
   end Poll;

   function C_Set_Size (Master, Pid, Rows, Cols : Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "pty_set_size";

   procedure Set_Size (H : in out Handle; Cols, Rows : Natural) is
      Rc : Interfaces.C.int;
      pragma Unreferenced (Rc);
   begin
      if not H.Open then
         return;
      end if;
      if Cols not in 1 .. 1000 or else Rows not in 1 .. 1000 then
         return;
      end if;
      Rc := C_Set_Size (H.Master, H.Pid,
                        Interfaces.C.int (Rows),
                        Interfaces.C.int (Cols));
   end Set_Size;

   procedure Close (H : in out Handle) is
      Dummy : Interfaces.C.int;
      pragma Unreferenced (Dummy);
   begin
      if H.Open then
         H.Open := False;
         Dummy := C_Close (H.Master, H.Pid);
         H.Master := -1;
         H.Pid := -1;
      end if;
   end Close;

end Tedex_Shell;
