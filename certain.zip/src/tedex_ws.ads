--  WebSocket framing per RFC 6455 (server side of the handshake,
--  unmasked server frames, masked client frames). Fully in SPARK.
package Tedex_Ws with SPARK_Mode is

   Ws_Guid : constant String := "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

   Max_Key_In : constant := 64;

   --  Sec-WebSocket-Accept value for a client key. Always 28 chars.
   --  Boundary obligation: caller must normalize Client_Key to First = 1.
   function Accept_Key (Client_Key : String) return String
     with Pre  => Client_Key'First = 1
                  and Client_Key'Length in 1 .. Max_Key_In,
          Post => Accept_Key'Result'Length = 28
                  and Accept_Key'Result'First = 1,
          Global => null,
          Depends => (Accept_Key'Result => Client_Key);

   Max_Frame_Payload : constant := 32_768;

   --  Encode one server->client frame (never masked).
   --  Opcode: 2 = binary, 8 = close, 9 = ping, 10 = pong; 0 = continuation.
   procedure Encode_Frame (Payload : String;
                           Opcode  : Natural;
                           Frame   : out String;
                           Frame_Len : out Natural;
                           Fin     : Boolean := True)
     with Pre  => Payload'First = 1 and Payload'Length <= Max_Frame_Payload
                  and (Opcode in 0 .. 2 or Opcode in 8 .. 10)
                  and Frame'First = 1
                  and Frame'Length >= 10 + Max_Frame_Payload,
          Post => Frame_Len = Payload'Length
                    + (if Payload'Length < 126 then 2 else 4),
          Global => null,
          Depends => (Frame =>+ (Payload, Opcode, Fin),
                      Frame_Len => Payload);

   --  Encode one client->server frame (masked, as RFC 6455 requires).
   --  Mask is a fresh 4-byte key chosen by the caller.
   procedure Encode_Client_Frame (Payload : String;
                                  Opcode  : Natural;
                                  Mask    : String;
                                  Frame   : out String;
                                  Frame_Len : out Natural;
                                  Fin     : Boolean := True)
     with Pre  => Payload'First = 1 and Payload'Length <= Max_Frame_Payload
                  and (Opcode in 0 .. 2 or Opcode in 8 .. 10)
                  and Mask'First = 1 and Mask'Length = 4
                  and Frame'First = 1
                  and Frame'Length >= 14 + Max_Frame_Payload,
          Post => Frame_Len = Payload'Length
                    + (if Payload'Length < 126 then 6 else 8),
          Global => null,
          Depends => (Frame =>+ (Payload, Opcode, Mask, Fin),
                      Frame_Len => Payload);

   Msg_Cap : constant := 1_000_000;

   type Frame_Header is record
      Fin     : Boolean := False;
      Opcode  : Natural range 0 .. 15 := 0;
      Pay_Len : Natural range 0 .. Msg_Cap := 0;
      Hdr_Len : Natural range 2 .. 14 := 2;
   end record;

   --  Validate one frame header.
   --  Require_Mask=True validates client->server headers (mask REQUIRED);
   --  False validates server->client headers (mask FORBIDDEN).
   --  Data holds exactly the header bytes (2 + ext-length + mask-if-any).
   procedure Decode_Header (Data : String;
                            H    : out Frame_Header;
                            Ok   : out Boolean;
                            Require_Mask : Boolean := True)
     with Pre => Data'First = 1 and Data'Length in 2 .. 14,
          Global => null,
          Depends => ((H, Ok) => (Data, Require_Mask));

   --  Remove the client mask in place. Mask is the 4-byte masking key.
   procedure Xor_Mask (Data : in out String; Mask : String)
     with Pre => Data'First = 1 and Mask'First = 1 and Mask'Length = 4,
          Global => null,
          Depends => (Data => (Data, Mask));

end Tedex_Ws;
