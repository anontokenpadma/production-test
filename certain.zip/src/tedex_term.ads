--  Manager-side attach relay (raw terminal). Boundary unit, not in SPARK.
--  Rationale for Off: termios/raw mode, poll on stdin, C imports.
--  Env assumptions: stdin/stdout fds 0/1, cfmakeraw available on tty.
with Interfaces.C;
with System;

package Tedex_Term with SPARK_Mode => Off is

   function Attach (Sock_Fd : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "term_attach";
   --  Relay stdin/stdout with sockfd; raw mode when stdin is a tty.
   --  Returns when the session ends.

   function C_Read_Line (Buf : System.Address; Max : Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "term_read_line";
   --  Unbuffered line read from stdin (see termhelp.c). Returns byte count
   --  including '\n', 0 on EOF, negative on error.

   procedure Term_Raw (On : Interfaces.C.int)
     with Import => True, Convention => C, External_Name => "term_raw";

   function Term_Set_Nonblock (Fd, On : Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "term_set_nonblock";

   function Term_Read_Chunk (Buf : System.Address; Max : Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "term_read_chunk";
   --  Single raw read on stdin: >0 bytes, 0 EOF, -2 no data, -1 error.

end Tedex_Term;
