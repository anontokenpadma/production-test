--  Socket line IO and relay. Boundary unit, not in SPARK.
--  Rationale for Off: GNAT.Sockets, poll(2), byte-at-a-time IO,
--  tasking (Pump), infinite relay loops; outside SPARK subset by design.
--  Env assumptions: TCP preserves byte order, pollCTL deadlines hold,
--  peer lines are LF-terminated and <= 2048 bytes else Net_Error.
with Ada.Strings.Unbounded;
with GNAT.Sockets;

package Tedex_Net with SPARK_Mode => Off is

   Net_Error : exception;

   Max_Line_Len : constant := 2048;

   procedure Send_Line (Sock : GNAT.Sockets.Socket_Type; S : String);
   --  Send S + LF. Raises Net_Error on failure.

   procedure Send_Data (Sock : GNAT.Sockets.Socket_Type; S : String);
   --  Send S as-is (no terminator). Raises Net_Error on failure.

   function Recv_Line (Sock    : GNAT.Sockets.Socket_Type;
                       Timeout : Duration := 3_600.0) return String;
   --  Read one LF-terminated line (CR stripped), normalized to First = 1.
   --  Raises Net_Error on timeout, close, or overlong line.

   procedure Splice (A, B : GNAT.Sockets.Socket_Type);
   --  Relay bytes both ways until EOF/error, then shut both down.

   function Wait_Readable (Sock : GNAT.Sockets.Socket_Type;
                             Timeout : Duration) return Boolean;
   --  Poll-based readability wait (no FD_SETSIZE limit). True = readable,
   --  False = timed out. Raises Net_Error on fd errors.

   procedure Ignore_Sigpipe;
   --  Call once at program start so a dead peer raises Socket_Error
   --  instead of killing the process.

   procedure Set_No_Delay (Sock : GNAT.Sockets.Socket_Type);
   --  Best-effort TCP_NODELAY (disables Nagle; crucial for interactive
   --  latency with small frames). Never raises.

   --  WebSocket (RFC 6455) -------------------------------------------

   function Peek_Http (Sock : GNAT.Sockets.Socket_Type) return Boolean;
   --  True when the pending bytes start with "GET " (HTTP/WebSocket).

   procedure Ws_Server_Handshake
     (Sock : GNAT.Sockets.Socket_Type;
      Path : out Ada.Strings.Unbounded.Unbounded_String);

   function Recv_Exact (Sock    : GNAT.Sockets.Socket_Type;
                        N       : Natural;
                        Timeout : Duration) return String;
   --  Exactly N bytes (never over-reads) or Net_Error.

   --  Read an HTTP Upgrade request, validate it, send 101.
   --  Plain non-upgrade HTTP gets a 404 reply. Anything else: Net_Error.

   procedure Ws_Send (Sock   : GNAT.Sockets.Socket_Type;
                      Data   : String;
                      Opcode : Natural := 2;
                      Masked : Boolean := False);
   --  Send one message, chunked into frames as needed. Opcode 2/8/9/10.
   --  Masked=True produces client-style (masked) frames.

   procedure Ws_Recv_Message (Sock    : GNAT.Sockets.Socket_Type;
                              Timeout : Duration := 3_600.0;
                              Payload : out Ada.Strings.Unbounded.Unbounded_String;
                              Masked_Replies : Boolean := False;
                              Masked_Expected : Boolean := True);
   --  Next complete message (fragmentation + ping/pong handled inside).
   --  Raises Net_Error("timeout") on idle timeout, Net_Error otherwise
   --  fatal (including a peer close frame, echoed first).
   --  Masked_Replies=True makes ping/close replies client-style (masked).
   --  Masked_Expected=False accepts unmasked (server-sent) frames.

   procedure Ws_Send_Line (Sock   : GNAT.Sockets.Socket_Type;
                           S      : String;
                           Masked : Boolean := False);
   function Ws_Recv_Line (Sock           : GNAT.Sockets.Socket_Type;
                          Timeout        : Duration := 3_600.0;
                          Masked_Replies : Boolean := False;
                          Masked_Expected : Boolean := True) return String;

   procedure Ws_Splice (S1 : GNAT.Sockets.Socket_Type; S1_Ws : Boolean;
                        S2 : GNAT.Sockets.Socket_Type; S2_Ws : Boolean);
   --  Relay with per-side framing plus WS keepalive pings.

   procedure Ws_Client_Handshake (Sock       : GNAT.Sockets.Socket_Type;
                                  Host, Path, Key : String);
   --  Send an upgrade request over an open socket; validate the 101 reply
   --  including the accept key. Raises Net_Error on any mismatch.

   function Ws_Pong_Count return Natural;
   --  Inbound WS pongs auto-consumed so far (saturating). Lets a
   --  single-connection client verify a peer is really alive while
   --  idling: auto-replied pings would otherwise hide a silent death.
   --  The multi-connection server never reads it (it only feeds it).

end Tedex_Net;
