--  Base64 encoding (RFC 4648, standard alphabet). Fully in SPARK.
package Tedex_B64 with SPARK_Mode is

   B64_Max_In  : constant := 64;
   B64_Max_Out : constant := 4 * ((B64_Max_In + 2) / 3);  --  88

   function Encode (Data : String) return String
     with Pre  => Data'First = 1 and Data'Length <= B64_Max_In,
          Post => Encode'Result'Length = 4 * ((Data'Length + 2) / 3)
                  and Encode'Result'First = 1,
          Global => null,
          Depends => (Encode'Result => Data);

end Tedex_B64;
