package body Tedex_Protocol with SPARK_Mode is

   procedure Parse_Auth (Line : String; Req : out Auth_Request) is
      subtype Word_No is Integer range 1 .. 5;
      W_Data : array (Word_No) of String (1 .. Max_Pass) :=
        [others => [others => ' ']];
      W_Len  : array (Word_No) of Natural range 0 .. Max_Pass := [others => 0];
      NW   : Integer range 0 .. 5 := 0;
      In_W : Boolean := False;
   begin
      Req := (Kind     => Auth_Bad,
              User     => [others => ' '], User_Len => 0,
              Pass     => [others => ' '], Pass_Len => 0,
              Dev      => [others => ' '], Dev_Len  => 0);
      for I in 1 .. Line'Length loop
         pragma Loop_Invariant (NW <= 5);
         pragma Loop_Invariant (if In_W then NW in 1 .. 5);
         if Line (I) = ' ' then
            In_W := False;
         elsif not In_W then
            if NW = 5 then
               return;  --  too many words
            end if;
            NW := NW + 1;
            In_W := True;
            W_Len (NW) := 1;
            W_Data (NW) (1) := Line (I);
         else
            if W_Len (NW) = Max_Pass then
               return;  --  word too long
            end if;
            W_Len (NW) := W_Len (NW) + 1;
            W_Data (NW) (W_Len (NW)) := Line (I);
         end if;
      end loop;
      if NW /= 5 then
         return;
      end if;
      if W_Len (1) /= 4 or else W_Data (1) (1 .. 4) /= "AUTH" then
         return;
      end if;
      if W_Len (2) = 6 and then W_Data (2) (1 .. 6) = "device" then
         Req.Kind := Auth_Device;
      elsif W_Len (2) = 7 and then W_Data (2) (1 .. 7) = "manager" then
         Req.Kind := Auth_Manager;
      else
         return;
      end if;
      if W_Len (3) not in 1 .. Max_Name then
         Req.Kind := Auth_Bad;
         return;
      end if;
      if W_Len (4) not in 1 .. Max_Pass then
         Req.Kind := Auth_Bad;
         return;
      end if;
      Req.User_Len := W_Len (3);
      Req.User (1 .. Req.User_Len) := W_Data (3) (1 .. W_Len (3));
      Req.Pass_Len := W_Len (4);
      Req.Pass (1 .. Req.Pass_Len) := W_Data (4) (1 .. W_Len (4));
      if Req.Kind = Auth_Device then
         if W_Len (5) not in 1 .. Max_Dev then
            Req.Kind := Auth_Bad;
            return;
         end if;
         Req.Dev_Len := W_Len (5);
         Req.Dev (1 .. Req.Dev_Len) := W_Data (5) (1 .. W_Len (5));
      else
         if W_Len (5) /= 1 or else W_Data (5) (1) /= '-' then
            Req.Kind := Auth_Bad;
            return;
         end if;
         Req.Dev_Len := 0;
      end if;
   end Parse_Auth;

   procedure Parse_Command (Line    : String;
                            Cmd     : out Manager_Cmd;
                            Arg     : out String;
                            Arg_Len : out Natural) is
      subtype Word_No is Integer range 1 .. 2;
      W_Data : array (Word_No) of String (1 .. Max_Dev) :=
        [others => [others => ' ']];
      W_Len  : array (Word_No) of Natural range 0 .. Max_Dev := [others => 0];
      NW   : Integer range 0 .. 2 := 0;
      In_W : Boolean := False;
   begin
      Arg := [others => ' '];
      Cmd := Cmd_Bad;
      Arg_Len := 0;
      for I in 1 .. Line'Length loop
         pragma Loop_Invariant (NW <= 2);
         pragma Loop_Invariant (if In_W then NW in 1 .. 2);
         if Line (I) = ' ' then
            In_W := False;
         elsif not In_W then
            if NW = 2 then
               return;
            end if;
            NW := NW + 1;
            In_W := True;
            W_Len (NW) := 1;
            W_Data (NW) (1) := Line (I);
         else
            if W_Len (NW) = Max_Dev then
               return;
            end if;
            W_Len (NW) := W_Len (NW) + 1;
            W_Data (NW) (W_Len (NW)) := Line (I);
         end if;
      end loop;
      if NW = 1 and then W_Len (1) = 4
        and then W_Data (1) (1 .. 4) = "LIST"
      then
         Cmd := Cmd_List;
      elsif NW = 1 and then W_Len (1) = 4
        and then (W_Data (1) (1 .. 4) = "QUIT"
                 or else W_Data (1) (1 .. 4) = "EXIT")
      then
         Cmd := Cmd_Quit;
      elsif NW = 2 and then W_Len (1) = 6
        and then W_Data (1) (1 .. 6) = "ATTACH"
        and then W_Len (2) in 1 .. Max_Dev
      then
         Cmd := Cmd_Attach;
         Arg_Len := W_Len (2);
         Arg (1 .. Arg_Len) := W_Data (2) (1 .. W_Len (2));
      elsif NW = 2 and then W_Len (1) = 6
        and then W_Data (1) (1 .. 6) = "REMOVE"
        and then W_Len (2) in 1 .. Max_Dev
      then
         Cmd := Cmd_Remove;
         Arg_Len := W_Len (2);
         Arg (1 .. Arg_Len) := W_Data (2) (1 .. W_Len (2));
      else
         Cmd := Cmd_Bad;
      end if;
   end Parse_Command;

   function Nat_Image (N : Natural) return String is
      Buf  : String (1 .. 6) := [others => '0'];
      X    : Natural := N;
      Pos  : Integer range 0 .. 6;
      Done : Integer range 0 .. 5 := 0;

      function Digit (V : Natural) return Character is
      begin
         return Character'Val (Character'Pos ('0') + (V mod 10));
      end Digit;
   begin
      if X = 0 then
         return "0";
      end if;
      Buf (6) := Digit (X mod 10);
      X := X / 10;
      Pos := 5;
      for I in 1 .. 5 loop
         pragma Loop_Invariant (Done = I - 1);
         pragma Loop_Invariant (Pos = 5 - Done);
         exit when X = 0;
         Buf (Pos) := Digit (X mod 10);
         X := X / 10;
         Pos := Pos - 1;
         Done := Done + 1;
      end loop;
      pragma Assert (Pos in 0 .. 5);
      return Buf (Pos + 1 .. 6);
   end Nat_Image;

   function Devices_Header (N : Natural) return String is
     ("DEVICES " & Nat_Image (N));

   function Devices_Allowed (Active_Count, Limit : Natural) return Boolean is
     (Active_Count < Limit);

   function Is_Token_Char (C : Character) return Boolean is
     (C in 'a' .. 'z' or C in 'A' .. 'Z'
      or C in '0' .. '9' or C = '_' or C = '-' or C = '.');

   function Is_Hex_Char (C : Character) return Boolean is
     (C in '0' .. '9' or C in 'a' .. 'f'
      or C in 'A' .. 'F');

   function Valid_Token (S : String) return Boolean is
   begin
      if S'Length not in 1 .. Max_Name then
         return False;
      end if;
      for I in S'Range loop
         pragma Loop_Invariant
           (for all J in S'First .. I - 1 => Is_Token_Char (S (J)));
         if not Is_Token_Char (S (I)) then
            return False;
         end if;
      end loop;
      return True;
   end Valid_Token;

   procedure Parse_Start_Dims (Line : String; Cols, Rows : out Natural) is
      I    : Integer := 12;
      C, R : Natural := 0;
   begin
      Cols := 0;
      Rows := 0;
      if Line'Length < 11 or else Line (1 .. 11) /= "SHELL_START" then
         return;
      end if;
      while I <= Line'Last and then Line (I) = ' ' loop
         pragma Loop_Invariant (I in 12 .. Line'Last + 1);
         I := I + 1;
      end loop;
      if I > Line'Last then
         return;  --  plain SHELL_START: keep defaults
      end if;
      while I <= Line'Last and then Line (I) in '0' .. '9' loop
         pragma Loop_Invariant (C <= 1000);
         pragma Loop_Invariant (I in 12 .. Line'Last + 1);
         C := C * 10 + (Character'Pos (Line (I)) - Character'Pos ('0'));
         exit when C > 1000;
         I := I + 1;
      end loop;
      while I <= Line'Last and then Line (I) = ' ' loop
         pragma Loop_Invariant (I in 12 .. Line'Last + 1);
         I := I + 1;
      end loop;
      while I <= Line'Last and then Line (I) in '0' .. '9' loop
         pragma Loop_Invariant (R <= 1000);
         pragma Loop_Invariant (I in 12 .. Line'Last + 1);
         R := R * 10 + (Character'Pos (Line (I)) - Character'Pos ('0'));
         exit when R > 1000;
         I := I + 1;
      end loop;
      while I <= Line'Last and then Line (I) = ' ' loop
         pragma Loop_Invariant (I in 12 .. Line'Last + 1);
         I := I + 1;
      end loop;
      if I <= Line'Last
        or else C not in 1 .. 1000
        or else R not in 1 .. 1000
      then
         return;
      end if;
      Cols := C;
      Rows := R;
   end Parse_Start_Dims;

   procedure Parse_Resize (Line    : String;
                           Dev     : out String;
                           Dev_Len : out Natural;
                           Cols    : out Natural;
                           Rows    : out Natural;
                           Ok      : out Boolean) is
      I        : Integer := 8;
      Cc, Rr   : Natural := 0;
      DL       : Natural := 0;
   begin
      Dev := [others => ' '];
      Dev_Len := 0;
      Cols := 0;
      Rows := 0;
      Ok := False;
      if Line'Length < 8 or else Line (1 .. 7) /= "RESIZE " then
         return;
      end if;
      while I <= Line'Last
        and then (Line (I) = ' ' or Line (I) = ASCII.HT)
      loop
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         I := I + 1;
      end loop;
      while I <= Line'Last
        and then Line (I) /= ' ' and then Line (I) /= ASCII.HT
      loop
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         pragma Loop_Invariant (DL <= Max_Dev);
         if DL = Max_Dev then
            return;  --  token too long (as > Max_Dev reject)
         end if;
         DL := DL + 1;
         Dev (DL) := Line (I);
         I := I + 1;
      end loop;
      if DL not in 1 .. Max_Dev then
         return;
      end if;
      while I <= Line'Last
        and then (Line (I) = ' ' or Line (I) = ASCII.HT)
      loop
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         I := I + 1;
      end loop;
      while I <= Line'Last and then Line (I) in '0' .. '9' loop
         pragma Loop_Invariant (Cc <= 1000);
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         Cc := Cc * 10 + (Character'Pos (Line (I)) - Character'Pos ('0'));
         exit when Cc > 1000;
         I := I + 1;
      end loop;
      while I <= Line'Last
        and then (Line (I) = ' ' or Line (I) = ASCII.HT)
      loop
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         I := I + 1;
      end loop;
      while I <= Line'Last and then Line (I) in '0' .. '9' loop
         pragma Loop_Invariant (Rr <= 1000);
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         Rr := Rr * 10 + (Character'Pos (Line (I)) - Character'Pos ('0'));
         exit when Rr > 1000;
         I := I + 1;
      end loop;
      while I <= Line'Last
        and then (Line (I) = ' ' or Line (I) = ASCII.HT)
      loop
         pragma Loop_Invariant (I in 8 .. Line'Last + 1);
         I := I + 1;
      end loop;
      if I <= Line'Last then
         return;  --  trailing garbage
      end if;
      if Cc not in 1 .. 1000 or else Rr not in 1 .. 1000 then
         return;
      end if;
      if not Valid_Token (Dev (Dev'First .. Dev'First + DL - 1)) then
         return;
      end if;
      --  Single commit point: every failure path above leaves the
      --  zeroed outputs untouched, so the postcondition holds.
      Dev_Len := DL;
      Cols := Cc;
      Rows := Rr;
      Ok := True;
   end Parse_Resize;

   function Backoff_Secs (Failures : Natural) return Natural is
   begin
      --  5 * 2**(min(Failures,5)-1), capped at 60, written out: the
      --  exponentiation form chokes solvers on nonlinear arithmetic
      --  while this is mere case analysis.
      case Failures is
         when 1 => return 5;
         when 2 => return 10;
         when 3 => return 20;
         when 4 => return 40;
         when others => return 60;
      end case;
   end Backoff_Secs;

end Tedex_Protocol;
