--  SHA-1 binary digest wrapper (needed for the WebSocket handshake).
--  Spec is SPARK (callable from proved code); body is off (OS library call).
package Tedex_SHA1 with SPARK_Mode is

   SHA1_Bytes : constant := 20;

   function Digest20 (S : String) return String
     with Pre    => S'Length <= 128 and S'First = 1,
          Post   => Digest20'Result'Length = SHA1_Bytes
                    and Digest20'Result'First = 1,
          Global => null;

end Tedex_SHA1;
