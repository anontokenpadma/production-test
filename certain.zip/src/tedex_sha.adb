with GNAT.SHA256;

package body Tedex_SHA with SPARK_Mode => Off is

   function Digest (S : String) return String is
      D : constant String := GNAT.SHA256.Digest (S);
      R : String (1 .. SHA_Hex_Len);
   begin
      R := D;
      return R;
   end Digest;

end Tedex_SHA;
