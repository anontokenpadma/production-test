with Tedex_SHA;

package body Tedex_Crypto with SPARK_Mode is

   function Hash_Password (Password : String; Salt : Salt_String) return Hash_String is
      Acc : Hash_String := Tedex_SHA.Digest (Salt & Password);
   begin
      for K in 2 .. Iterations loop
         pragma Loop_Invariant
           (Acc'Length = Hash_Len and Acc'First = 1);
         Acc := Tedex_SHA.Digest (Salt & Acc);
      end loop;
      return Acc;
   end Hash_Password;

   function Secure_Equal (A, B : String) return Boolean is
      Diff : Natural := 0;
   begin
      for I in A'Range loop
         pragma Loop_Invariant (Diff <= I - A'First);
         pragma Loop_Invariant (I - A'First <= A'Length);
         if Character'Pos (A (I))
           /= Character'Pos (B (B'First + (I - A'First)))
         then
            Diff := Diff + 1;
         end if;
      end loop;
      return Diff = 0;
   end Secure_Equal;

   procedure Split_Stored (Stored : String;
                           Salt   : out Salt_String;
                           Hash   : out Hash_String;
                           Ok     : out Boolean) is
   begin
      Salt := [others => ' '];
      Hash := [others => ' '];
      Ok   := False;
      if Stored'Length /= Stored_Len then
         return;
      end if;
      if Stored (Stored'First + Salt_Len) /= '$' then
         return;
      end if;
      Salt := Stored (Stored'First .. (Stored'First + Salt_Len) - 1);
      Hash := Stored ((Stored'First + Salt_Len) + 1 ..
                      (Stored'First + Stored_Len) - 1);
      Ok := True;
   end Split_Stored;

   function Is_Password_Char (C : Character) return Boolean is
     (C /= ' ' and C /= ':' and C /= ASCII.LF and C /= ASCII.CR);

   function Valid_Password (S : String) return Boolean is
   begin
      if S'Length not in 1 .. Max_Password_Len then
         return False;
      end if;
      for I in S'Range loop
         pragma Loop_Invariant
           (for all J in S'First .. I - 1 => Is_Password_Char (S (J)));
         if not Is_Password_Char (S (I)) then
            return False;
         end if;
      end loop;
      return True;
   end Valid_Password;

end Tedex_Crypto;
