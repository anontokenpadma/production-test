--  SHA-256 primitive wrapper.
--  Spec is SPARK (callable from proved code); body is off (OS library call).
package Tedex_SHA with SPARK_Mode is

   SHA_Hex_Len : constant := 64;

   function Digest (S : String) return String
     with Pre    => S'Length <= 512 and S'First = 1,
          Post   => Digest'Result'Length = SHA_Hex_Len
                    and Digest'Result'First = 1,
          Global => null;

end Tedex_SHA;
