--  Device-side shell: spawn /bin/bash on a directly managed pty and
--  exchange bytes with the server. Reads drain until EIO, so no output
--  is ever lost when the shell exits. Boundary unit, not in SPARK.
--  Rationale for Off: fork/pty syscalls via C, blocking poll with
--  timeouts; outside SPARK subset by design.
--  Env assumptions: /bin/bash exists, pty EIO means drained child exit.
--
--  NOTE: Shell_Error is deliberately distinct from Tedex_Net.Net_Error
--  so callers can tell "shell died" (clean session end) apart from
--  "transport broke" (reconnect / exit).
with Interfaces.C;

use type Interfaces.C.int;

package Tedex_Shell with SPARK_Mode => Off is

   Shell_Error : exception;

   type Handle is limited private;

   procedure Spawn (H : out Handle);
   --  Start the shell. Raises Shell_Error when bash cannot start.

   procedure Send (H : in out Handle; Data : String);
   --  Feed bytes to the shell. Raises Shell_Error when it is dead.

   function Poll (H : in out Handle; Timeout_Ms : Natural := 1) return String;
   --  Pending shell output, or "" when there is none.
   --  Raises Shell_Error when the shell has exited AND drained.

   procedure Close (H : in out Handle);

   procedure Set_Size (H : in out Handle; Cols, Rows : Natural);
   --  Resize the pty to Cols x Rows, then SIGWINCH the child so
   --  bash/readline and curses apps re-query it. Best effort and never
   --  raises: out-of-range dims or a failed ioctl are silently ignored
   --  so a bad size can never kill a session.

private

   type Handle is limited record
      Master : Interfaces.C.int := -1;
      Pid    : Interfaces.C.int := -1;
      Open   : Boolean := False;
   end record;

end Tedex_Shell;
