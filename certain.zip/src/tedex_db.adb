with Ada.Calendar.Formatting;
with Ada.Directories;
with Ada.Streams.Stream_IO;
with Ada.Text_IO;
with Interfaces.C;
with Interfaces.C.Strings;
with System;
with System.Storage_Elements;

with Tedex_Crypto;
with Tedex_Protocol;

package body Tedex_DB with SPARK_Mode => Off is

   use Ada.Strings.Unbounded;
   use Ada.Text_IO;
   use type Interfaces.C.int;
   use type System.Address;
   use type System.Storage_Elements.Integer_Address;
   use type Interfaces.Integer_64;

   SQLITE_OPEN_READWRITE : constant := 16#00000002#;
   SQLITE_OPEN_CREATE    : constant := 16#00000004#;
   SQLITE_OPEN_FULLMUTEX : constant := 16#00010000#;
   SQLITE_OK   : constant := 0;
   SQLITE_ROW  : constant := 100;
   SQLITE_DONE : constant := 101;

   SQLITE_TRANSIENT : constant System.Address :=
     System.Storage_Elements.To_Address (-1);

   function C_Open (Name  : Interfaces.C.Strings.chars_ptr;
                    Db    : System.Address;
                    Flags : Interfaces.C.int;
                    Vfs   : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_open_v2";

   function C_Close (Db : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_close";

   function C_Exec (Db   : System.Address;
                    Sql  : Interfaces.C.Strings.chars_ptr;
                    Cb   : System.Address;
                    Arg  : System.Address;
                    Err  : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_exec";

   function C_Prepare (Db   : System.Address;
                       Sql  : Interfaces.C.Strings.chars_ptr;
                       N    : Interfaces.C.int;
                       Stmt : System.Address;
                       Tail : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_prepare_v2";

   function C_Bind_Text (Stmt : System.Address;
                         Idx  : Interfaces.C.int;
                         Val  : Interfaces.C.Strings.chars_ptr;
                         N    : Interfaces.C.int;
                         Des  : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_bind_text";

   function C_Step (Stmt : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_step";

   function C_Column_Text (Stmt : System.Address;
                           Col  : Interfaces.C.int)
     return Interfaces.C.Strings.chars_ptr
     with Import => True, Convention => C, External_Name => "sqlite3_column_text";

   function C_Column_Bytes (Stmt : System.Address;
                            Col  : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_column_bytes";

   function C_Column_Int (Stmt : System.Address;
                          Col  : Interfaces.C.int)
     return Interfaces.Integer_64
     with Import => True, Convention => C, External_Name => "sqlite3_column_int64";

   function C_Finalize (Stmt : System.Address) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_finalize";

   function C_Busy_Timeout (Db : System.Address;
                            Ms : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "sqlite3_busy_timeout";

   procedure Check (Rc : Interfaces.C.int; What : String) is
   begin
      if Rc /= SQLITE_OK then
         raise DB_Error with What;
      end if;
   end Check;

   procedure Exec (Db : System.Address; Sql : String) is
      use Interfaces.C.Strings;
      Csql : chars_ptr := New_String (Sql);
      Rc   : Interfaces.C.int;
   begin
      Rc := C_Exec (Db, Csql, System.Null_Address, System.Null_Address,
                    System.Null_Address);
      Free (Csql);
      Check (Rc, Sql);
   end Exec;

   procedure Prepare (Db : System.Address; Sql : String;
                      Stmt : out System.Address) is
      use Interfaces.C.Strings;
      Csql : chars_ptr := New_String (Sql);
      S    : aliased System.Address := System.Null_Address;
      Rc   : Interfaces.C.int;
   begin
      Rc := C_Prepare (Db, Csql, -1, S'Address, System.Null_Address);
      Free (Csql);
      Check (Rc, Sql);
      Stmt := S;
   end Prepare;

   procedure Bind (Stmt : System.Address; Idx : Positive; Val : String) is
      use Interfaces.C.Strings;
      C : chars_ptr := New_String (Val);
      Rc : Interfaces.C.int;
   begin
      Rc := C_Bind_Text (Stmt, Interfaces.C.int (Idx), C,
                         Interfaces.C.int (Val'Length), SQLITE_TRANSIENT);
      Free (C);
      Check (Rc, "bind");
   end Bind;

   procedure Finalize (Stmt : in out System.Address) is
      Rc : Interfaces.C.int;
      pragma Unreferenced (Rc);
   begin
      if Stmt /= System.Null_Address then
         Rc := C_Finalize (Stmt);
         Stmt := System.Null_Address;
      end if;
   end Finalize;

   --  Read-only text column, capped. Returns "" when NULL/oversize.
   function Col_Text (Stmt : System.Address; Col : Natural) return String is
      use Interfaces.C.Strings;
      P : constant chars_ptr :=
        C_Column_Text (Stmt, Interfaces.C.int (Col));
      N : constant Interfaces.C.int :=
        C_Column_Bytes (Stmt, Interfaces.C.int (Col));
   begin
      if P = Null_Ptr or else N <= 0 or else N > 2_048 then
         return "";
      end if;
      declare
         Full : constant String := Value (P);
      begin
         if Full'Length < Natural (N) then
            return "";
         end if;
         return Full (Full'First .. Full'First + Natural (N) - 1);
      end;
   end Col_Text;

   function Safe_Token (S : String) return Boolean is
   begin
      return Tedex_Protocol.Valid_Token (S);
   end Safe_Token;

   function Now_Stamp return String is
   begin
      return Ada.Calendar.Formatting.Image (Ada.Calendar.Clock);
   end Now_Stamp;

   procedure Open_Schema (Db : System.Address) is
   begin
      Exec (Db, "PRAGMA journal_mode=WAL;");
      Exec (Db, "CREATE TABLE IF NOT EXISTS users"
                & "(username TEXT PRIMARY KEY, pass_hash TEXT NOT NULL,"
                & " disabled INTEGER NOT NULL DEFAULT 0,"
                & " device_limit INTEGER NOT NULL DEFAULT 10);");
      Exec (Db, "CREATE TABLE IF NOT EXISTS devices"
                & "(username TEXT NOT NULL, dev TEXT NOT NULL,"
                & " last_seen TEXT NOT NULL,"
                & " PRIMARY KEY (username, dev));");
      Exec (Db, "CREATE TABLE IF NOT EXISTS tombstones"
                & "(username TEXT NOT NULL, dev TEXT NOT NULL,"
                & " PRIMARY KEY (username, dev));");
      Exec (Db, "CREATE TABLE IF NOT EXISTS devkeys"
                & "(username TEXT PRIMARY KEY, stored TEXT NOT NULL);");
   end Open_Schema;

   function Open_DB (Path : String) return System.Address is
      use Interfaces.C.Strings;
      Cpath : chars_ptr := New_String (Path);
      Db    : aliased System.Address := System.Null_Address;
      Rc    : Interfaces.C.int;
   begin
      Rc := C_Open (Cpath, Db'Address,
                    SQLITE_OPEN_READWRITE + SQLITE_OPEN_CREATE
                    + SQLITE_OPEN_FULLMUTEX,
                    System.Null_Address);
      Free (Cpath);
      Check (Rc, "open");
      Rc := C_Busy_Timeout (Db, 5_000);
      Check (Rc, "busy_timeout");
      Open_Schema (Db);
      return Db;
   exception
      when others =>
         if Db /= System.Null_Address then
            declare
               Rc2 : Interfaces.C.int;
               pragma Unreferenced (Rc2);
            begin
               Rc2 := C_Close (Db);
            end;
         end if;
         raise;
   end Open_DB;

   procedure Close_DB (Db : in out System.Address) is
      Rc : Interfaces.C.int;
      pragma Unreferenced (Rc);
   begin
      if Db /= System.Null_Address then
         Rc := C_Close (Db);
         Db := System.Null_Address;
      end if;
   end Close_DB;

   --  Split "a:b:c..." tail at first two colons. Returns False when the
   --  shape is wrong. F1/F2 are the first two fields, Rest is the tail.
   function Split2 (S : String; F1, F2 : out Unbounded_String;
                    Rest : out Unbounded_String) return Boolean is
      C1 : Integer := S'First;
   begin
      F1 := Null_Unbounded_String;
      F2 := Null_Unbounded_String;
      Rest := Null_Unbounded_String;
      while C1 <= S'Last and then S (C1) /= ':' loop
         C1 := C1 + 1;
      end loop;
      if C1 > S'Last then
         return False;
      end if;
      F1 := To_Unbounded_String (S (S'First .. C1 - 1));
      declare
         R2 : constant String := S (C1 + 1 .. S'Last);
         C2 : Integer := R2'First;
      begin
         while C2 <= R2'Last and then R2 (C2) /= ':' loop
            C2 := C2 + 1;
         end loop;
         if C2 > R2'Last then
            F2 := To_Unbounded_String (R2);
            return True;
         end if;
         F2 := To_Unbounded_String (R2 (R2'First .. C2 - 1));
         Rest := To_Unbounded_String (R2 (C2 + 1 .. R2'Last));
         return True;
      end;
   end Split2;

   --  One-shot legacy flat-file import (accounts, @devices, !tombstones,
   --  %keys). Runs at most once per path: afterwards the file is SQLite.
   --  The original is kept as Path & ".flatbak".
   procedure Maybe_Migrate_Legacy (Path : String) is
      use type Ada.Streams.Stream_Element_Offset;
      F     : Ada.Streams.Stream_IO.File_Type;
      Magic : Ada.Streams.Stream_Element_Array (1 .. 16);
      Last  : Ada.Streams.Stream_Element_Offset;
      Db    : System.Address := System.Null_Address;
   begin
      if not Ada.Directories.Exists (Path) then
         return;
      end if;
      begin
         Ada.Streams.Stream_IO.Open (F, Ada.Streams.Stream_IO.In_File, Path);
         Ada.Streams.Stream_IO.Read (F, Magic, Last);
         Ada.Streams.Stream_IO.Close (F);
      exception
         when others =>
            return;
      end;
      if Last = 0 then
         return;  --  empty: sqlite opens it fine
      end if;
      if Last >= 15 then
         declare
            Head : String (1 .. 15);
         begin
            for I in 1 .. 15 loop
               Head (I) :=
                 Character'Val
                   (Magic (Ada.Streams.Stream_Element_Offset (I)));
            end loop;
            if Head = "SQLite format 3" then
               return;
            end if;
         end;
      end if;
      --  Legacy flat file: parse everything, build a fresh sqlite db
      --  aside, then swap (original preserved as .flatbak).
      declare
         TF : Ada.Text_IO.File_Type;
         procedure Import_Account (Line : String) is
            Acc : Tedex_Store.Account;
            Ok  : Boolean;
            Stmt : System.Address := System.Null_Address;
         begin
            Tedex_Store.Parse_Account_Line (Line, Acc, Ok);
            if not Ok then
               return;
            end if;
            --  Values come from the validated SPARK parser: the name
            --  charset excludes quotes, so literal embedding is safe.
            Prepare (Db, "INSERT OR IGNORE INTO users"
                         & "(username, pass_hash, disabled, device_limit)"
                         & " VALUES('"
                         & Acc.Name (1 .. Acc.Name_Len) & "','"
                         & Acc.Hash & "',"
                         & (if Acc.Disabled then "1" else "0") & ","
                         & Natural'Image (Acc.Limit) & ");", Stmt);
            if C_Step (Stmt) /= SQLITE_DONE then
               Finalize (Stmt);
               raise DB_Error with "migrate account";
            end if;
            Finalize (Stmt);
         end Import_Account;
      begin
         Db := Open_DB (Path & ".migrating");
         Open (TF, In_File, Path);
         while not End_Of_File (TF) loop
            declare
               Line : constant String := Get_Line (TF);
            begin
               if Line'Length = 0 then
                  null;
               elsif Line (Line'First) = '@' then
                  declare
                     F1, F2, Ts : Unbounded_String;
                  begin
                     if Split2 (Line (Line'First + 1 .. Line'Last),
                                F1, F2, Ts)
                       and then Safe_Token (To_String (F1))
                       and then Safe_Token (To_String (F2))
                     then
                        declare
                           Stmt : System.Address := System.Null_Address;
                        begin
                           Prepare (Db, "INSERT OR IGNORE INTO devices"
                                        & "(username, dev, last_seen)"
                                        & " VALUES(?, ?, ?);", Stmt);
                           Bind (Stmt, 1, To_String (F1));
                           Bind (Stmt, 2, To_String (F2));
                           Bind (Stmt, 3, To_String (Ts));
                           if C_Step (Stmt) /= SQLITE_DONE then
                              Finalize (Stmt);
                              raise DB_Error with "migrate device";
                           end if;
                           Finalize (Stmt);
                        end;
                     end if;
                  end;
               elsif Line (Line'First) = '!' then
                  declare
                     F1, F2, Ts : Unbounded_String;
                  begin
                     if Split2 (Line (Line'First + 1 .. Line'Last),
                                F1, F2, Ts)
                       and then Safe_Token (To_String (F1))
                       and then Safe_Token (To_String (F2))
                     then
                        declare
                           Stmt : System.Address := System.Null_Address;
                        begin
                           Prepare (Db, "INSERT OR IGNORE INTO tombstones"
                                        & "(username, dev) VALUES(?, ?);",
                                     Stmt);
                           Bind (Stmt, 1, To_String (F1));
                           Bind (Stmt, 2, To_String (F2));
                           if C_Step (Stmt) /= SQLITE_DONE then
                              Finalize (Stmt);
                              raise DB_Error with "migrate tomb";
                           end if;
                           Finalize (Stmt);
                        end;
                     end if;
                  end;
               elsif Line (Line'First) = '%' then
                  declare
                     F1, F2, Ts : Unbounded_String;
                  begin
                     if Split2 (Line (Line'First + 1 .. Line'Last),
                                F1, F2, Ts)
                     then
                        --  stored secret kept verbatim (shape-checked).
                        declare
                           S : constant String := To_String (F2);
                        begin
                           if S'Length = Tedex_Crypto.Stored_Len
                             and then Safe_Token (To_String (F1))
                           then
                              declare
                                 Stmt : System.Address := System.Null_Address;
                              begin
                                 Prepare (Db, "INSERT OR IGNORE INTO devkeys"
                                              & "(username, stored)"
                                              & " VALUES(?, ?);", Stmt);
                                 Bind (Stmt, 1, To_String (F1));
                                 Bind (Stmt, 2, S);
                                 if C_Step (Stmt) /= SQLITE_DONE then
                                    Finalize (Stmt);
                                    raise DB_Error with "migrate key";
                                 end if;
                                 Finalize (Stmt);
                              end;
                           end if;
                        end;
                     end if;
                  end;
               else
                  Import_Account (Line);
               end if;
            end;
         end loop;
         Close (TF);
         Close_DB (Db);
         Ada.Directories.Rename (Path, Path & ".flatbak");
         Ada.Directories.Rename (Path & ".migrating", Path);
      exception
         when others =>
            if Ada.Text_IO.Is_Open (TF) then
               Close (TF);
            end if;
            Close_DB (Db);
            if Ada.Directories.Exists (Path & ".migrating") then
               Ada.Directories.Delete_File (Path & ".migrating");
            end if;
      end;
   end Maybe_Migrate_Legacy;

   function Load (Path : String) return Acct_Vectors.Vector is
      V  : Acct_Vectors.Vector;
      Db : System.Address := System.Null_Address;
   begin
      Maybe_Migrate_Legacy (Path);
      Db := Open_DB (Path);
      declare
         Stmt : System.Address := System.Null_Address;
         Rc   : Interfaces.C.int;
      begin
         Prepare (Db, "SELECT username, pass_hash, disabled, device_limit"
                      & " FROM users ORDER BY username;", Stmt);
         loop
            Rc := C_Step (Stmt);
            if Rc = SQLITE_DONE then
               exit;
            elsif Rc /= SQLITE_ROW then
               --  BUSY/LOCKED/IO mid-scan (burst contention): ending
               --  here would return a partial vector and misreport
               --  existing accounts as unknown (permanent client-side).
               Finalize (Stmt);
               raise DB_Error with "load step";
            end if;
            declare
               Nm : constant String := Col_Text (Stmt, 0);
               Hs : constant String := Col_Text (Stmt, 1);
               Di : constant Interfaces.Integer_64 :=
                 C_Column_Int (Stmt, 2);
               Li : constant Interfaces.Integer_64 :=
                 C_Column_Int (Stmt, 3);
               Acc : Tedex_Store.Account;
            begin
               if Safe_Token (Nm)
                 and then Hs'Length = Tedex_Crypto.Stored_Len
                 and then Di in 0 .. 1
                 and then Li in 1 .. Tedex_Store.Max_Limit
               then
                  declare
                     Salt : Tedex_Crypto.Salt_String;
                     HH   : Tedex_Crypto.Hash_String;
                     HOk  : Boolean;
                     Hbuf : constant String (1 .. Tedex_Crypto.Stored_Len) :=
                       Hs;
                  begin
                     Tedex_Crypto.Split_Stored (Hbuf, Salt, HH, HOk);
                     if HOk then
                        Acc.Name_Len := Nm'Length;
                        Acc.Name (1 .. Nm'Length) := Nm;
                        Acc.Hash := Salt & "$" & HH;
                        Acc.Disabled := Di = 1;
                        Acc.Limit := Natural (Li);
                        V.Append (Acc);
                     end if;
                  end;
               end if;
            end;
         end loop;
         Finalize (Stmt);
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
      Close_DB (Db);
      return V;
   exception
      when others =>
         --  Never return a partial vector: callers treat a missing
         --  account as a permanent auth refusal, so a transient
         --  lock/IO failure must propagate (callers answer transient
         --  callers with "busy, retry" instead).
         Close_DB (Db);
         raise;
   end Load;

   function Trimmed (N : Natural) return String is
      S : constant String := Natural'Image (N);
   begin
      if S'Length >= 2 and then S (S'First) = ' ' then
         return S (S'First + 1 .. S'Last);
      end if;
      return S;
   end Trimmed;

   procedure Save_All (Path : String; V : Acct_Vectors.Vector) is
      Db : System.Address := System.Null_Address;
   begin
      Maybe_Migrate_Legacy (Path);
      Db := Open_DB (Path);
      Exec (Db, "BEGIN IMMEDIATE;");
      begin
         Exec (Db, "DELETE FROM users;");
         for Acc of V loop
            declare
               Stmt : System.Address := System.Null_Address;
            begin
               Prepare (Db, "INSERT INTO users"
                            & "(username, pass_hash, disabled, device_limit)"
                            & " VALUES(?, ?, ?, ?);", Stmt);
               Bind (Stmt, 1, Acc.Name (1 .. Acc.Name_Len));
               Bind (Stmt, 2, String (Acc.Hash));
               Bind (Stmt, 3,
                     (if Acc.Disabled then "1" else "0"));
               Bind (Stmt, 4, Trimmed (Acc.Limit));
               if C_Step (Stmt) /= SQLITE_DONE then
                  Finalize (Stmt);
                  raise DB_Error with "save";
               end if;
               Finalize (Stmt);
            end;
         end loop;
         Exec (Db, "COMMIT;");
      exception
         when others =>
            begin
               Exec (Db, "ROLLBACK;");
            exception
               when others => null;
            end;
            raise;
      end;
      Close_DB (Db);
   exception
      when others =>
         Close_DB (Db);
         raise;
   end Save_All;

   procedure Remove_Account (DB_Path, User : String; Removed : out Boolean) is
      Db : System.Address := System.Null_Address;
   begin
      Removed := False;
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      Exec (Db, "BEGIN IMMEDIATE;");
      begin
         declare
            Stmt : System.Address := System.Null_Address;
            Rc   : Interfaces.C.int;
         begin
            Prepare (Db, "SELECT 1 FROM users WHERE username = ? LIMIT 1;",
                     Stmt);
            Bind (Stmt, 1, User);
            Rc := C_Step (Stmt);
            Finalize (Stmt);
            if Rc /= SQLITE_ROW then
               Exec (Db, "ROLLBACK;");
               Close_DB (Db);
               return;
            end if;
         exception
            when others =>
               Finalize (Stmt);
               raise;
         end;
         declare
            Stmt : System.Address := System.Null_Address;
            procedure Wipe (Table : String) is
            begin
               Prepare (Db, "DELETE FROM " & Table & " WHERE username = ?;",
                        Stmt);
               Bind (Stmt, 1, User);
               if C_Step (Stmt) /= SQLITE_DONE then
                  Finalize (Stmt);
                  raise DB_Error with "wipe " & Table;
               end if;
               Finalize (Stmt);
               Stmt := System.Null_Address;
            end Wipe;
         begin
            Wipe ("users");
            Wipe ("devices");
            Wipe ("tombstones");
            Wipe ("devkeys");
         exception
            when others =>
               Finalize (Stmt);
               raise;
         end;
         Exec (Db, "COMMIT;");
         Removed := True;
      exception
         when others =>
            begin
               Exec (Db, "ROLLBACK;");
            exception
               when others => null;
            end;
            raise;
      end;
      Close_DB (Db);
   exception
      when others =>
         Close_DB (Db);
         raise;
   end Remove_Account;

   function Find (V : Acct_Vectors.Vector; Name : String) return Natural is
   begin
      for I in 1 .. Natural (V.Length) loop
         declare
            Acc : constant Tedex_Store.Account := V (I);
         begin
            if Acc.Name_Len = Name'Length
              and then Acc.Name (1 .. Acc.Name_Len) = Name
            then
               return I;
            end if;
         end;
      end loop;
      return 0;
   end Find;

   procedure Touch_Device (DB_Path, User, Dev : String) is
      Db : System.Address := System.Null_Address;
   begin
      if not Safe_Token (User) or else not Safe_Token (Dev) then
         return;
      end if;
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
      begin
         Prepare (Db, "INSERT OR REPLACE INTO devices"
                      & "(username, dev, last_seen) VALUES(?, ?, ?);", Stmt);
         Bind (Stmt, 1, User);
         Bind (Stmt, 2, Dev);
         Bind (Stmt, 3, Now_Stamp);
         if C_Step (Stmt) /= SQLITE_DONE then
            Finalize (Stmt);
            raise DB_Error with "touch";
         end if;
         Finalize (Stmt);
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
      Close_DB (Db);
   exception
      when others =>
         Close_DB (Db);
         null;
   end Touch_Device;

   function Known_Devices (DB_Path, User : String)
     return Known_Vec.Vector
   is
      V  : Known_Vec.Vector;
      Db : System.Address := System.Null_Address;
   begin
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
         Rc   : Interfaces.C.int;
      begin
         Prepare (Db, "SELECT dev, last_seen FROM devices"
                      & " WHERE username = ? ORDER BY dev;", Stmt);
         Bind (Stmt, 1, User);
         loop
            Rc := C_Step (Stmt);
            exit when Rc /= SQLITE_ROW;
            declare
               D : constant String := Col_Text (Stmt, 0);
               T : constant String := Col_Text (Stmt, 1);
            begin
               if Safe_Token (D) then
                  V.Append (Known_Rec'(Dev => To_Unbounded_String (D),
                                       Last_Seen => To_Unbounded_String (T)));
               end if;
            end;
         end loop;
         Finalize (Stmt);
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
      Close_DB (Db);
      return V;
   exception
      when others =>
         Close_DB (Db);
         return V;
   end Known_Devices;

   procedure Remember_Removed (DB_Path, User, Dev : String) is
      Db : System.Address := System.Null_Address;
   begin
      if not Safe_Token (User) or else not Safe_Token (Dev) then
         return;
      end if;
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
      begin
         Prepare (Db, "INSERT OR IGNORE INTO tombstones"
                      & "(username, dev) VALUES(?, ?);", Stmt);
         Bind (Stmt, 1, User);
         Bind (Stmt, 2, Dev);
         if C_Step (Stmt) /= SQLITE_DONE then
            Finalize (Stmt);
            raise DB_Error with "remember";
         end if;
         Finalize (Stmt);
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
      Close_DB (Db);
   exception
      when others =>
         Close_DB (Db);
         null;
   end Remember_Removed;

   function Is_Removed (DB_Path, User, Dev : String) return Boolean is
      Db : System.Address := System.Null_Address;
   begin
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
         Rc   : Interfaces.C.int;
      begin
         Prepare (Db, "SELECT 1 FROM tombstones"
                      & " WHERE username = ? AND dev = ? LIMIT 1;", Stmt);
         Bind (Stmt, 1, User);
         Bind (Stmt, 2, Dev);
         Rc := C_Step (Stmt);
         Finalize (Stmt);
         Close_DB (Db);
         return Rc = SQLITE_ROW;
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
   exception
      when others =>
         Close_DB (Db);
         return False;
   end Is_Removed;

   procedure Forget_Device (DB_Path, User, Dev : String) is
      Db : System.Address := System.Null_Address;
   begin
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
      begin
         Prepare (Db, "DELETE FROM devices"
                      & " WHERE username = ? AND dev = ?;", Stmt);
         Bind (Stmt, 1, User);
         Bind (Stmt, 2, Dev);
         if C_Step (Stmt) /= SQLITE_DONE then
            Finalize (Stmt);
            raise DB_Error with "forget";
         end if;
         Finalize (Stmt);
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
      Close_DB (Db);
   exception
      when others =>
         Close_DB (Db);
         null;
   end Forget_Device;

   procedure Store_Key (DB_Path, User, Stored : String) is
      Db : System.Address := System.Null_Address;
   begin
      if not Safe_Token (User) then
         return;
      end if;
      if Stored'Length /= Tedex_Crypto.Stored_Len then
         return;
      end if;
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
      begin
         Prepare (Db, "INSERT OR REPLACE INTO devkeys"
                      & "(username, stored) VALUES(?, ?);", Stmt);
         Bind (Stmt, 1, User);
         Bind (Stmt, 2, Stored);
         if C_Step (Stmt) /= SQLITE_DONE then
            Finalize (Stmt);
            raise DB_Error with "store key";
         end if;
         Finalize (Stmt);
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
      Close_DB (Db);
   exception
      when others =>
         Close_DB (Db);
         null;
   end Store_Key;

   function Has_Key (DB_Path, User : String) return Boolean is
      Db : System.Address := System.Null_Address;
   begin
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
         Rc   : Interfaces.C.int;
      begin
         Prepare (Db, "SELECT 1 FROM devkeys"
                      & " WHERE username = ? LIMIT 1;", Stmt);
         Bind (Stmt, 1, User);
         Rc := C_Step (Stmt);
         Finalize (Stmt);
         Close_DB (Db);
         return Rc = SQLITE_ROW;
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
   exception
      when others =>
         Close_DB (Db);
         return False;
   end Has_Key;

   function Verify_Key (DB_Path, User, Token : String) return Boolean is
      Db : System.Address := System.Null_Address;
   begin
      if Token'Length not in 1 .. 128 then
         return False;
      end if;
      Maybe_Migrate_Legacy (DB_Path);
      Db := Open_DB (DB_Path);
      declare
         Stmt : System.Address := System.Null_Address;
         Rc   : Interfaces.C.int;
      begin
         Prepare (Db, "SELECT stored FROM devkeys"
                      & " WHERE username = ? LIMIT 1;", Stmt);
         Bind (Stmt, 1, User);
         Rc := C_Step (Stmt);
         if Rc = SQLITE_DONE then
            Finalize (Stmt);
            Close_DB (Db);
            return False;  --  genuinely no key stored
         elsif Rc /= SQLITE_ROW then
            --  BUSY/LOCKED mid-read: returning False would misreport
            --  a valid key as a bad password (permanent client-side).
            Finalize (Stmt);
            Close_DB (Db);
            raise DB_Error with "verify step";
         end if;
         declare
            Stored : constant String := Col_Text (Stmt, 0);
         begin
            Finalize (Stmt);
            Close_DB (Db);
            if Stored'Length /= Tedex_Crypto.Stored_Len then
               return False;
            end if;
            declare
               S : constant String (1 .. Tedex_Crypto.Stored_Len) := Stored;
               Salt : Tedex_Crypto.Salt_String;
               HH   : Tedex_Crypto.Hash_String;
               HOk  : Boolean;
            begin
               Tedex_Crypto.Split_Stored (S, Salt, HH, HOk);
               if not HOk then
                  return False;
               end if;
               declare
                  Calc : constant Tedex_Crypto.Hash_String :=
                    Tedex_Crypto.Hash_Password (Token, Salt);
               begin
                  return Tedex_Crypto.Secure_Equal
                    (String (Calc), String (HH));
               end;
            end;
         end;
      exception
         when others =>
            Finalize (Stmt);
            raise;
      end;
   exception
      when others =>
         --  Same rule as Load: a store failure must propagate so the
         --  server answers "busy, retry" instead of misreading a valid
         --  enrollment key as a bad password (permanent deprovision).
         Close_DB (Db);
         raise;
   end Verify_Key;

end Tedex_DB;
