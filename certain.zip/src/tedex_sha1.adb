with Ada.Streams;
with GNAT.SHA1;

package body Tedex_SHA1 with SPARK_Mode => Off is

   use Ada.Streams;

   function Digest20 (S : String) return String is
      D : constant Stream_Element_Array := GNAT.SHA1.Digest (S);
      R : String (1 .. SHA1_Bytes);
   begin
      for I in R'Range loop
         R (I) := Character'Val (D (Stream_Element_Offset (I)));
      end loop;
      return R;
   end Digest20;

end Tedex_SHA1;
