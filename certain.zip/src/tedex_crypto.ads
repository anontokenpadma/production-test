--  Password hashing and stored-secret handling. Fully in SPARK.
package Tedex_Crypto with SPARK_Mode is

   Salt_Len   : constant := 32;
   Hash_Len   : constant := 64;
   Stored_Len : constant := Salt_Len + 1 + Hash_Len;  --  "salt$hash"

   Max_Password_Len : constant := 128;
   Iterations       : constant := 10_000;

   subtype Salt_String is String (1 .. Salt_Len);
   subtype Hash_String is String (1 .. Hash_Len);

   --  Stretched hash: H0 = SHA256 (Salt & Password), Hn = SHA256 (Salt & Hn-1)
   --  Boundary obligation: caller must ensure Password'First = 1
   --  (all current callers pass a normalized slice or fresh String).
   function Hash_Password (Password : String; Salt : Salt_String) return Hash_String
     with Pre => Password'Length in 1 .. Max_Password_Len,
          Global => null,
          Depends => (Hash_Password'Result => (Password, Salt));

   --  Constant-time comparison (no early exit).
   function Secure_Equal (A, B : String) return Boolean
     with Pre => A'Length = B'Length,
          Global => null,
          Depends => (Secure_Equal'Result => (A, B));

   --  Split "salt$hash" into parts. Ok is False on any shape error.
   procedure Split_Stored (Stored : String;
                           Salt   : out Salt_String;
                           Hash   : out Hash_String;
                           Ok     : out Boolean)
     with Pre  => Stored'First = 1 and Stored'Length <= Stored_Len,
          Post => (if Ok then Stored'Length = Stored_Len),
          Global => null,
          Depends => ((Salt, Hash, Ok) => Stored);

   function Is_Password_Char (C : Character) return Boolean
     with Post => Is_Password_Char'Result =
                   (C /= ' ' and C /= ':' and C /= ASCII.LF and C /= ASCII.CR),
          Global => null,
          Depends => (Is_Password_Char'Result => C);

   --  Account password / device-key policy (1..128, no space/colon/newline).
   --  Total function: usable from boundary units without precondition.
   function Valid_Password (S : String) return Boolean
     with Post => Valid_Password'Result =
                   (S'Length in 1 .. Max_Password_Len
                    and (for all C of S => Is_Password_Char (C))),
          Global => null,
          Depends => (Valid_Password'Result => S);

end Tedex_Crypto;
