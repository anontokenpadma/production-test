/* TLS byte stream via an "openssl s_client" subprocess.
   The parent gets two pipe fds (read side + write side). */
#define _DEFAULT_SOURCE
#define _XOPEN_SOURCE 600
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

/* Wait for readability on one fd. No FD_SETSIZE limit (unlike select).
   Returns 1 readable, 0 timeout, -2 interrupted, -1 error. */
int fd_wait_read (int fd, int timeout_ms)
{
   struct pollfd p;
   int r;
   p.fd = fd;
   p.events = POLLIN;
   p.revents = 0;
   r = poll (&p, 1, timeout_ms < 0 ? -1 : timeout_ms);
   if (r < 0)
      return errno == EINTR ? -2 : -1;
   if (r == 0)
      return 0;
   if (p.revents & (POLLERR | POLLNVAL))
      return -1;
   return 1;
}

/* Wait on two fds. Returns bitmask (1 and/or 2), 0 timeout, -2 intr, -1 err. */
int fds_wait_read (int fd1, int fd2, int timeout_ms)
{
   struct pollfd p[2];
   int r, out = 0;
   p[0].fd = fd1;
   p[0].events = POLLIN;
   p[0].revents = 0;
   p[1].fd = fd2;
   p[1].events = POLLIN;
   p[1].revents = 0;
   r = poll (p, 2, timeout_ms < 0 ? -1 : timeout_ms);
   if (r < 0)
      return errno == EINTR ? -2 : -1;
   if (r == 0)
      return 0;
   if (p[0].revents & (POLLIN | POLLHUP))
      out |= 1;
   else if (p[0].revents & (POLLERR | POLLNVAL))
      return -1;
   if (p[1].revents & (POLLIN | POLLHUP))
      out |= 2;
   else if (p[1].revents & (POLLERR | POLLNVAL))
      return -1;
   return out == 0 ? 0 : out;
}

/* Spawn: openssl s_client -connect host:port -servername host -quiet
   -verify_hostname host. Returns 0 ok (rfd/wfd/pid set), -1 on failure. */
int tls_open (const char *host, int port, int *rfd, int *wfd, int *pid)
{
   int to_child[2], from_child[2];
   if (host == 0 || host[0] == '\0' || port <= 0 || port > 65535)
      return -1;
   if (pipe (to_child) < 0 || pipe (from_child) < 0)
      return -1;
   {
      int cpid = fork ();
      if (cpid < 0) {
         close (to_child[0]); close (to_child[1]);
         close (from_child[0]); close (from_child[1]);
         return -1;
      }
      if (cpid == 0) {
         /* child: stdin/stdout become the pipes, stderr silenced */
         dup2 (to_child[0], 0);
         dup2 (from_child[1], 1);
         {
            int dn = open ("/dev/null", O_WRONLY);
            if (dn >= 0)
               dup2 (dn, 2);
         }
         close (to_child[0]); close (to_child[1]);
         close (from_child[0]); close (from_child[1]);
         {
            char portstr[16];
            char target[320];
            snprintf (portstr, sizeof portstr, "%d", port);
            snprintf (target, sizeof target, "%s:%s", host, portstr);
            execlp ("openssl", "openssl", "s_client",
                    "-connect", target,
                    "-servername", host,
                    "-quiet", "-verify_hostname", host,
                    (char *) 0);
         }
         _exit (127);
      }
      close (to_child[0]);
      close (from_child[1]);
      *wfd = to_child[1];
      *rfd = from_child[0];
      *pid = cpid;
      return 0;
   }
}

/* Best-effort reap (0 = reaped/gone, 1 = still running). */
int tls_reap (int pid)
{
   int st, i;
   if (pid <= 0)
      return 0;
   for (i = 0; i < 20; i++) {
      int r = waitpid (pid, &st, WNOHANG);
      if (r == pid)
         return 0;
      if (r < 0 && errno == ECHILD)
         return 0;
      usleep (100000);
   }
   return 1;
}

/* Signal a child (SIGTERM, then SIGKILL) and reap it. Always succeeds
   (best effort). Needed because a lingering "openssl s_client" would
   otherwise hold the TLS session open after our pipes are closed, so
   the far end never sees EOF. */
int tls_kill (int pid)
{
   int st, i;
   if (pid <= 0)
      return 0;
   kill (pid, SIGTERM);
   for (i = 0; i < 10; i++) {
      int r = waitpid (pid, &st, WNOHANG);
      if (r == pid)
         return 0;
      if (r < 0 && errno == ECHILD)
         return 0;
      usleep (100000);
   }
   kill (pid, SIGKILL);
   waitpid (pid, &st, 0);
   return 0;
}

int tls_close_fd (int fd)
{
   return close (fd);
}

/* --- pty shell backend (no Expect races: EIO comes only after drain) --- */

/* Write the managed device-shell init file and return its path in
   `out` (empty string when HOME is unusable: caller falls back to a
   plain "bash -i"). The file mirrors interactive non-login startup
   (the one file bash itself would source) and then neutralizes TMOUT
   auto-logout, which otherwise ends attached sessions that sit idle.
   Done with a file (not an injected command line) so nothing is ever
   echoed onto the session and the pty termios is never touched while
   bash initializes (bash snapshots it at its first prompt; any ECHO
   games around startup permanently corrupt its echo/newline handling
   for the whole session). Contains no secrets; rewritten each start
   so it always matches this binary. */
static void write_tedex_rc (const char *home, char *out, unsigned outlen)
{
   FILE *f;
   out[0] = '\0';
   if (home == 0 || home[0] == '\0')
      return;
   if (strlen (home) + 16 >= outlen)
      return;
   snprintf (out, outlen, "%s/.tedex_rc", home);
   f = fopen (out, "w");
   if (f == 0) {
      out[0] = '\0';
      return;
   }
   fputs ("# tedex device shell init (managed, rewritten at each start).\n", f);
   fputs ("# Mirrors interactive non-login startup, then kills TMOUT.\n", f);
   fputs ("if [ -f \"$HOME/.bashrc\" ]; then . \"$HOME/.bashrc\"; fi\n", f);
   fputs ("unset TMOUT 2>/dev/null; TMOUT=0; export TMOUT=0\n", f);
   fclose (f);
}

int pty_spawn_bash (int *master_fd, int *child_pid)
{
   int m = posix_openpt (O_RDWR | O_NOCTTY);
   if (m < 0)
      return -1;
   if (grantpt (m) < 0 || unlockpt (m) < 0) {
      close (m);
      return -1;
   }
   {
      /* A fresh pty is 0x0 rows/cols: curses/readline/tmux then see a
         zero-size terminal (tmux falls back to 80x24, long lines do not
         wrap at the right column). Default to 80x24 here; the relay may
         widen it later via pty_set_size once the manager reports its
         real size at attach time. Best effort: never fail spawn. */
      struct winsize ws;
      memset (&ws, 0, sizeof ws);
      ws.ws_col = 80;
      ws.ws_row = 24;
      ioctl (m, TIOCSWINSZ, &ws);
   }
   {
      char *slave = ptsname (m);
      int cpid;
      char rcf[4096];
      if (slave == 0) {
         close (m);
         return -1;
      }
      /* Decide the init file before forking (it must exist at exec;
         empty path = plain "bash -i" fallback). */
      write_tedex_rc (getenv ("HOME"), rcf, sizeof rcf);
      cpid = fork ();
      if (cpid < 0) {
         close (m);
         return -1;
      }
      if (cpid == 0) {
         /* child: new session, slave becomes controlling terminal */
         int s;
         /* systemd services have no TERM -> clear/tput fail with
            "TERM environment variable not set". Default only if unset
            so explicit TERM=dumb etc. is still respected. */
         if (getenv ("TERM") == 0)
            setenv ("TERM", "xterm-256color", 0);
         /* Idle auto-logout kills the relay: an inherited TMOUT makes
            "bash -i" print "timed out waiting for input: auto-logout"
            and exit with no one typing "exit", which surfaces on the
            manager as a mystery "session ended". The env default below
            covers exported TMOUT; rc-file TMOUT is neutralized by the
            managed ~/.tedex_rc init file (see write_tedex_rc); a
            readonly TMOUT baked into the image config cannot be
            overridden from here. */
         setenv ("TMOUT", "0", 1);
         close (m);
         setsid ();
         s = open (slave, O_RDWR);
         if (s < 0)
            _exit (127);
         dup2 (s, 0);
         dup2 (s, 1);
         dup2 (s, 2);
         if (s > 2)
            close (s);
         if (rcf[0] != '\0') {
            char *const argv_rc[] =
              { "/bin/bash", "--rcfile", rcf, "-i", 0 };
            execvp (argv_rc[0], argv_rc);
            /* Fall through to plain bash when the managed file cannot
               be used (same behavior as before this mechanism). */
         }
         {
            char *const argv[] = { "/bin/bash", "-i", 0 };
            execvp (argv[0], argv);
         }
         _exit (127);
      }
      *master_fd = m;
      *child_pid = cpid;
      return 0;
   }
}

/* Poll pty master. >0 bytes, 0 none yet, -1 drained/dead, -2 error.
   EIO counts as fatal only when the child is really gone (startup race). */
int pty_poll (int master, int pid, char *buf, int max, int timeout_ms)
{
   struct pollfd p;
   p.fd = master;
   p.events = POLLIN;
   p.revents = 0;
   {
      int s = poll (&p, 1, timeout_ms);
      if (s < 0) {
         if (errno == EINTR)
            return 0;
         return -2;
      }
      if (s == 0)
         return 0;
   }
   {
      long k = read (master, buf, (unsigned) max);
      if (k > 0)
         return (int) k;
      if (k < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR))
         return 0;
      if (k < 0 && errno == EIO) {
         int st;
         /* EIO with a live child = startup race, not death */
         if (waitpid (pid, &st, WNOHANG) == 0)
            return 0;
      }
      return -1;
   }
}

/* Resize a live pty and nudge the foreground child so bash/readline
   and curses apps re-query the size. Returns 0 ok, -1 on failure.
   Best effort: a failed resize must never kill a session. */
int pty_set_size (int master, int pid, int rows, int cols)
{
   struct winsize ws;
   if (master < 0 || pid <= 0 || rows <= 0 || cols <= 0
       || rows > 1000 || cols > 1000)
      return -1;
   memset (&ws, 0, sizeof ws);
   ws.ws_row = (unsigned short) rows;
   ws.ws_col = (unsigned short) cols;
   if (ioctl (master, TIOCSWINSZ, &ws) < 0)
      return -1;
   kill (pid, SIGWINCH);
   return 0;
}

/* Manager-side terminal size from fd 0. Returns 0 ok (*rows/*cols set),
   -1 when unknown (not a tty, zero size, or error): caller falls back
   to 80x24 rather than propagating 0x0. */
int term_get_size (int *rows, int *cols)
{
   struct winsize ws;
   if (rows == 0 || cols == 0)
      return -1;
   *rows = 0;
   *cols = 0;
   memset (&ws, 0, sizeof ws);
   if (ioctl (0, TIOCGWINSZ, &ws) < 0)
      return -1;
   if (ws.ws_row <= 0 || ws.ws_col <= 0
       || ws.ws_row > 1000 || ws.ws_col > 1000)
      return -1;
   *rows = ws.ws_row;
   *cols = ws.ws_col;
   return 0;
}

/* Terminate, reap and close. Always succeeds (best effort). */
int pty_close (int master, int pid)
{
   int i, st;
   if (pid > 0) {
      kill (pid, SIGTERM);
      for (i = 0; i < 10; i++) {
         if (waitpid (pid, &st, WNOHANG) == pid)
            break;
         usleep (100000);
      }
      if (waitpid (pid, &st, WNOHANG) != pid) {
         kill (pid, SIGKILL);
         waitpid (pid, &st, 0);
      }
   }
   if (master >= 0)
      close (master);
   return 0;
}

/* Blocking read with millisecond timeout.
   Returns bytes (>0), 0 EOF, -2 retry (EINTR/EAGAIN), -3 timeout, -1 error. */
int fd_read_timeout (int fd, char *buf, int n, int timeout_ms)
{
   struct pollfd p;
   p.fd = fd;
   p.events = POLLIN;
   p.revents = 0;
   {
      int s = poll (&p, 1, timeout_ms);
      if (s < 0) {
         if (errno == EINTR)
            return -2;
         return -1;
      }
      if (s == 0)
         return -3;
   }
   {
      long k = read (fd, buf, (unsigned) n);
      if (k < 0) {
         if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
            return -2;
         return -1;
      }
      return (int) k;
   }
}

/* Write all bytes. Returns 0 ok, -1 on error. */
int fd_write_all (int fd, const char *b, int n)
{
   int off = 0;
   while (off < n) {
      long w = write (fd, b + off, (unsigned) (n - off));
      if (w < 0) {
         if (errno == EINTR)
            continue;
         return -1;
      }
      if (w == 0)
         return -1;
      off += (int) w;
   }
   return 0;
}
