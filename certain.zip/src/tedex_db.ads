--  Flat-file account database plus known-device registry.
--  Boundary unit (file IO), not in SPARK.
--  Rationale for Off: direct sqlite3 C bindings via System.Address,
--  file rename, wall-clock stamps; outside SPARK subset by design.
--  Env assumptions (unchecked, caller-visible): sqlite3 lib present,
--  filesystem supports atomic rename, single-writer + busy_timeout 5s
--  is sufficient, wall clock is monotonic enough for last_seen.
with Ada.Containers.Vectors;
with Ada.Strings.Unbounded;
with Tedex_Store;

package Tedex_DB with SPARK_Mode => Off is

   use type Tedex_Store.Account;

   DB_Error : exception;
   --  Raised when the store cannot be read or written (lock/IO). Never
   --  swallowed into a wrong answer on auth paths (see Load/Verify_Key).

   package Acct_Vectors is new Ada.Containers.Vectors
     (Index_Type => Positive, Element_Type => Tedex_Store.Account);

   --  Load all accounts; missing file means empty database.
   --  Raises DB_Error when the store cannot be read (lock/IO): callers
   --  must answer transient callers with a retryable error, never with
   --  an auth refusal (those are permanent client-side).
   function Load (Path : String) return Acct_Vectors.Vector;

   --  Atomically replace the database file (write temp + rename).
   procedure Save_All (Path : String; V : Acct_Vectors.Vector);

   --  Index (1-based) of Name in V, or 0 when absent.
   function Find (V : Acct_Vectors.Vector; Name : String) return Natural;

   procedure Remove_Account (DB_Path, User : String; Removed : out Boolean);
   --  Delete the account and every related row (devices, tombstones,
   --  device key) atomically. Removed is True when the user existed.

   --  Known devices (ever registered), with last-seen stamps.
   type Known_Rec is record
      Dev       : Ada.Strings.Unbounded.Unbounded_String;
      Last_Seen : Ada.Strings.Unbounded.Unbounded_String;
   end record;

   package Known_Vec is new Ada.Containers.Vectors
     (Positive, Known_Rec);

   procedure Touch_Device (DB_Path, User, Dev : String);
   --  Record (user, dev) as known with last_seen=now (upsert).

   procedure Remember_Removed (DB_Path, User, Dev : String);
   --  Tombstone a removed device id (line "!user:dev").

   function Is_Removed (DB_Path, User, Dev : String) return Boolean;
   --  True when a tombstone exists.

   procedure Store_Key (DB_Path, User, Stored : String);
   --  Upsert the account device-key (stored "salt$hash" form).

   function Verify_Key (DB_Path, User, Token : String) return Boolean;
   --  True when Token matches the stored device-key. Raises DB_Error
   --  when the store cannot be read (a read failure is not a mismatch:
   --  callers must answer retryable, never "bad password").

   function Has_Key (DB_Path, User : String) return Boolean;
   --  True when the account has a device-key stored.

   procedure Forget_Device (DB_Path, User, Dev : String);
   --  Delete known-device (@user:dev) records.

   function Known_Devices (DB_Path, User : String)
     return Known_Vec.Vector;
   --  All known devices of a user, oldest first.

end Tedex_DB;
