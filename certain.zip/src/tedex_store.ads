--  Account record plus parsing/serialization of DB lines.
--  Fully in SPARK. DB file format per line:  name:salt$hash:disabled:limit
with Tedex_Crypto;
with Tedex_Protocol;

package Tedex_Store with SPARK_Mode is

   Max_Account_Line : constant := 256;
   Max_Limit        : constant := 10_000;

   type Account is record
      Name     : String (1 .. Tedex_Protocol.Max_Name) := [others => ' '];
      Name_Len : Natural range 0 .. Tedex_Protocol.Max_Name := 0;
      Hash     : String (1 .. Tedex_Crypto.Stored_Len) := [others => ' '];
      Disabled : Boolean := False;
      Limit    : Natural range 1 .. Max_Limit := 10;
   end record;

   --  Parse one "name:hash:0|1:limit" line. Ok is False on any shape error.
   --  Boundary obligation: caller must normalize Line to First = 1.
   procedure Parse_Account_Line (Line : String;
                                 Acc  : out Account;
                                 Ok   : out Boolean)
     with Pre => Line'First = 1 and Line'Length <= Max_Account_Line,
          Global => null,
          Depends => ((Acc, Ok) => Line);

   function Format_Account_Line (Acc : Account) return String
     with Post => Format_Account_Line'Result'Length <= Max_Account_Line
                  and Format_Account_Line'Result'First = 1,
          Global => null,
          Depends => (Format_Account_Line'Result => Acc);

end Tedex_Store;
