--  TLS byte streams via an "openssl s_client" subprocess, plus raw
--  fd read/write helpers. Boundary unit, not in SPARK.
--  Rationale for Off: fork/exec of external openssl binary, pipe fds,
--  poll timeouts; outside SPARK subset by design.
--  Env assumptions: openssl binary in PATH, -verify_hostname enforces
--  hostname check, /dev/urandom available to callers for masks.
with Interfaces.C;
with Interfaces.C.Strings;
with System;

package Tedex_Tls with SPARK_Mode => Off is

   function Tls_Open (Host      : Interfaces.C.Strings.chars_ptr;
                      Port      : Interfaces.C.int;
                      Rfd, Wfd  : access Interfaces.C.int;
                      Pid       : access Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "tls_open";
   --  0 on success (fds + child pid set), -1 on failure.

   function Tls_Reap (Pid : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "tls_reap";

   function Tls_Kill (Pid : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "tls_kill";
   --  SIGTERM, then SIGKILL + reap. Always succeeds (best effort):
   --  makes sure a lingering "openssl s_client" cannot hold the TLS
   --  session open after we are done with it.

   function Tls_Close_Fd (Fd : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "tls_close_fd";

   function Fd_Read_Timeout (Fd         : Interfaces.C.int;
                             Buf        : System.Address;
                             N          : Interfaces.C.int;
                             Timeout_Ms : Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "fd_read_timeout";
   --  >0 bytes, 0 EOF, -2 retry, -3 timeout, -1 error.

   function Fd_Write_All (Fd  : Interfaces.C.int;
                          Buf : System.Address;
                          N   : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "fd_write_all";

   function Fd_Wait_Read (Fd         : Interfaces.C.int;
                          Timeout_Ms : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "fd_wait_read";
   --  1 readable, 0 timeout, -2 interrupted, -1 error. No FD_SETSIZE limit.

   function Fds_Wait_Read (Fd1, Fd2  : Interfaces.C.int;
                           Timeout_Ms : Interfaces.C.int) return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "fds_wait_read";
   --  Bitmask 1 and/or 2, 0 timeout, -2 interrupted, -1 error.

end Tedex_Tls;
