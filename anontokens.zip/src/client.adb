--  tedex client: device agent (-c) or manager dashboard (-u),
--  over raw TCP, ws:// or wss:// (WebSocket, plain or via openssl s_client).
--  Usage: ./client [-s host] [-p port] [--ws ws[s]://host[:port][/path]]
--                 -c user password [--name id] [-r] [--persist] [--uninstall]
--         ./client [-s host] [-p port] [--ws ...] -u user password
with Ada.Calendar;
with Ada.Command_Line;
with Ada.Directories;
with Ada.Environment_Variables;
with Ada.Exceptions;
with Ada.Streams;
with Ada.Streams.Stream_IO;
with Ada.Strings.Unbounded;
with Ada.Text_IO;
with GNAT.OS_Lib;
with GNAT.Sockets;
with Interfaces.C;
with Interfaces.C.Strings;

with Tedex_B64;
with Tedex_Net;
with Tedex_Protocol;
with Tedex_Shell;
with Tedex_Term;
with Tedex_Tls;
with Tedex_Ws;

--  Boundary main, not in SPARK (sockets, TLS subprocess, pty,
--  tasking); wire framing/parsing delegated to proved SPARK units.
procedure Client with SPARK_Mode => Off is

   use GNAT.Sockets;
   use Ada.Strings.Unbounded;
   use Tedex_Net;
   use Ada.Streams;
   use type Interfaces.C.int;

   Host   : Unbounded_String := To_Unbounded_String ("127.0.0.1");
   Port   : Integer := 9999;
   Is_Dev : Boolean := False;
   User   : Unbounded_String;
   Pass   : Unbounded_String;
   Dev_Id : Unbounded_String;
   Ws_Url : Unbounded_String := Null_Unbounded_String;

   Persist      : Boolean := False;  --  --persist: retry forever
   Do_Install   : Boolean := False;  --  -r: install systemd service
   Do_Uninstall : Boolean := False;  --  --uninstall: remove it
   Name_Given   : Boolean := False;  --  --name was explicit
   Was_Removed  : Boolean := False;  --  ordered to stop by manager

   type TKind is (T_Raw, T_Ws_Sock, T_Ws_Pipe);

   type Transport is record
      Kind      : TKind := T_Raw;
      Sock      : Socket_Type := No_Socket;
      Rfd, Wfd  : Interfaces.C.int := -1;
      Pid       : Interfaces.C.int := -1;
      Ws_Host   : Unbounded_String;
      Ws_Path   : Unbounded_String;
   end record;

   T : Transport;



   Mgr_Pongs_Seen : Natural := 0;
   --  Inbound WS pong counter (client side). The manager prompt loop
   --  uses it to verify the link is really alive while idling;
   --  auto-consumed pongs would otherwise hide a silent death.

   function Parse_Count (S : String) return Natural is
      V : Natural := 0;
   begin
      if S'Length = 0 or else S'Length > 6 then
         return 0;
      end if;
      for C of S loop
         if C not in '0' .. '9' then
            return 0;
         end if;
         V := V * 10 + (Character'Pos (C) - Character'Pos ('0'));
         if V > 999_999 then
            return 0;
         end if;
      end loop;
      return V;
   end Parse_Count;

   function Trimmed_Count (N : Natural) return String is
      S : constant String := Natural'Image (N);
   begin
      if S'Length >= 2 and then S (S'First) = ' ' then
         return S (S'First + 1 .. S'Last);
      end if;
      return S;
   end Trimmed_Count;

   --  Optional "SHELL_START <cols> <rows>" suffix from the server.
   --  Strict: digits only, both 1..1000, nothing else after the tag.
   --  Anything else yields 0,0 (keep the 80x24 spawn default).
   procedure Parse_Start_Dims (L : String; Cols, Rows : out Natural) is
      I : Integer := L'First + 11;
   begin
      Cols := 0;
      Rows := 0;
      if L'Length < 11
        or else L (L'First .. L'First + 10) /= "SHELL_START"
      then
         return;
      end if;
      while I <= L'Last and then L (I) = ' ' loop
         I := I + 1;
      end loop;
      if I > L'Last then
         return;  --  plain SHELL_START: keep defaults
      end if;
      declare
         C, R : Natural := 0;
      begin
         while I <= L'Last and then L (I) in '0' .. '9' loop
            C := C * 10 + (Character'Pos (L (I)) - Character'Pos ('0'));
            exit when C > 1000;
            I := I + 1;
         end loop;
         while I <= L'Last and then L (I) = ' ' loop
            I := I + 1;
         end loop;
         while I <= L'Last and then L (I) in '0' .. '9' loop
            R := R * 10 + (Character'Pos (L (I)) - Character'Pos ('0'));
            exit when R > 1000;
            I := I + 1;
         end loop;
         while I <= L'Last and then L (I) = ' ' loop
            I := I + 1;
         end loop;
         if I <= L'Last or else C not in 1 .. 1000 or else R not in 1 .. 1000 then
            return;
         end if;
         Cols := C;
         Rows := R;
      end;
   end Parse_Start_Dims;



   function C_Geteuid return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "geteuid";
   --  0 when running as root (system unit install instead of --user).

   function C_Get_Size (Rows, Cols : access Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "term_get_size";
   --  Manager tty size via TIOCGWINSZ on fd 0 (0 ok, -1 unknown):
   --  callers fall back to 80x24 rather than propagating 0x0.

   --  Stream buffers for WS poll loops ---------------------------------
   --  Attach_Ws polled MRecv (0.01s) and Run_Shell_Ws polled MRecv
   --  (0.001s). A frame split across two TCP/TLS arrivals with a gap
   --  longer than the poll slice timed out mid-message and DISCARDED the
   --  already-read header bytes, desyncing the stream ("bad frame" ->
   --  "session ended" under continuous output). These buffers keep every
   --  byte until a full message assembles; a poll with no complete
   --  message yet returns Got=False and loses nothing.
   Pipe_Raw : Unbounded_String := Null_Unbounded_String;  --  TLS-pipe bytes
   Sock_Raw : Unbounded_String := Null_Unbounded_String;  --  WS-socket bytes
   Frag_Msg : Unbounded_String := Null_Unbounded_String;  --  fragmented msg
   Frag_On  : Boolean := False;

   procedure Clear_Streams is
   begin
      Pipe_Raw := Null_Unbounded_String;
      Sock_Raw := Null_Unbounded_String;
      Frag_Msg := Null_Unbounded_String;
      Frag_On  := False;
   end Clear_Streams;

   function Rand_Bytes (N : Positive) return String is
      use Ada.Streams.Stream_IO;
      F    : File_Type;
      Buf  : Stream_Element_Array (1 .. Stream_Element_Offset (N));
      Last : Stream_Element_Offset;
      R    : String (1 .. N);
   begin
      Open (F, In_File, "/dev/urandom");
      Read (F, Buf, Last);
      Close (F);
      for I in 1 .. N loop
         R (I) := Character'Val (Buf (Stream_Element_Offset (I)));
      end loop;
      return R;
   end Rand_Bytes;

   function Rand_Hex (Bytes : Positive) return String is
      Raw : constant String := Rand_Bytes (Bytes);
      Hex : constant String := "0123456789abcdef";
      R   : String (1 .. Bytes * 2);
   begin
      for I in 1 .. Bytes loop
         R (2 * I - 1) :=
           Hex (Character'Pos (Raw (I)) / 16 + 1);
         R (2 * I) :=
           Hex (Character'Pos (Raw (I)) mod 16 + 1);
      end loop;
      return R;
   end Rand_Hex;

   function Resolve (H : String) return Inet_Addr_Type is
   begin
      return Inet_Addr (H);
   exception
      when Socket_Error =>
         return Addresses (Get_Host_By_Name (H), 1);
   end Resolve;

   function Connect_Sock (H : String; P : Integer) return Socket_Type is
      S    : Socket_Type;
      Addr : constant Sock_Addr_Type :=
        (Family => Family_Inet,
         Addr   => Resolve (H),
         Port   => Port_Type (P));
   begin
      Create_Socket (S);
      Connect_Socket (S, Addr);
      Set_No_Delay (S);
      return S;
   end Connect_Sock;

   procedure Close_Quiet (S : Socket_Type) is
   begin
      Close_Socket (S);
   exception
      when Socket_Error => null;
   end Close_Quiet;

   --  Pipe (openssl) byte IO --------------------------------------

   procedure Pipe_Send_All (Data : String) is
      use Interfaces.C;
      Rc : Interfaces.C.int;
   begin
      if Data'Length = 0 then
         return;
      end if;
      Rc := Tedex_Tls.Fd_Write_All (T.Wfd, Data'Address,
                                    Interfaces.C.int (Data'Length));
      if Rc /= 0 then
         raise Net_Error with "closed";
      end if;
   end Pipe_Send_All;

   function Pipe_Read_Exact (N : Natural; Deadln : Ada.Calendar.Time)
     return String
   is
      use Ada.Calendar;
      use Interfaces.C;
      Buf : String (1 .. Integer'Max (N, 1));
      Got : Natural := 0;
      Tmp : aliased String (1 .. 4096);
   begin
      if N = 0 then
         return "";
      end if;
      while Got < N loop
         declare
            Left : constant Duration := Deadln - Clock;
            Ms   : Integer;
            Rc   : Interfaces.C.int;
            Want : Integer;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            Ms := Integer (Left * 1_000.0);
            if Ms > 5_000 then
               Ms := 5_000;
            elsif Ms < 1 then
               Ms := 1;
            end if;
            Want := Integer'Min (4_096, N - Got);
            Rc := Tedex_Tls.Fd_Read_Timeout
              (T.Rfd, Tmp'Address,
               Interfaces.C.int (Want), Interfaces.C.int (Ms));
            if Rc > 0 then
               for I in 1 .. Natural (Rc) loop
                  Got := Got + 1;
                  Buf (Got) := Tmp (I);
               end loop;
            elsif Rc = 0 then
               raise Net_Error with "closed";
            elsif Rc = -3 then
               null;  --  timeout slice; re-check deadline above
            elsif Rc = -2 then
               null;  --  transient; retry
            else
               raise Net_Error with "socket error";
            end if;
         end;
      end loop;
      return Buf (1 .. N);
   end Pipe_Read_Exact;

   function Next_Mask return String is
      Raw : constant String := Rand_Bytes (4);
      M   : String (1 .. 4);
   begin
      M := Raw;
      return M;
   end Next_Mask;

   procedure Ws_Pipe_Send (Data : String; Opcode : Natural := 2) is
      Buf   : String (1 .. 14 + Tedex_Ws.Max_Frame_Payload);
      First : Integer := Data'First;
      Rest  : Integer := Data'Length;
      First_Frag : Boolean := True;
   begin
      if Rest = 0 then
         declare
            FL : Natural;
         begin
            Tedex_Ws.Encode_Client_Frame
              ("", Opcode, Next_Mask, Buf, FL, Fin => True);
            Pipe_Send_All (Buf (1 .. FL));
            return;
         end;
      end if;
      while Rest > 0 loop
         declare
            N   : constant Integer :=
              Integer'Min (Rest, Tedex_Ws.Max_Frame_Payload);
            Ch  : String (1 .. N);
            FL  : Natural;
            Op  : constant Natural :=
              (if First_Frag then Opcode else 0);
         begin
            Ch := Data (First .. First + N - 1);
            Tedex_Ws.Encode_Client_Frame
              (Ch, Op, Next_Mask, Buf, FL, Fin => (N = Rest));
            Pipe_Send_All (Buf (1 .. FL));
            First := First + N;
            Rest := Rest - N;
            First_Frag := False;
         end;
      end loop;
   end Ws_Pipe_Send;

   procedure Ws_Pipe_Recv_Message
     (Timeout : Duration := 3_600.0;
      Payload : out Unbounded_String)
   is
      use Ada.Calendar;
      Deadln  : constant Time := Clock + Timeout;
      Msg     : Unbounded_String := Null_Unbounded_String;
      Started : Boolean := False;
   begin
      Payload := Null_Unbounded_String;
      loop
         declare
            Hdr2 : constant String := Pipe_Read_Exact (2, Deadln);
            L7   : constant Natural :=
              Character'Pos (Hdr2 (Hdr2'Last)) mod 128;
            Ext  : constant Natural :=
              (if L7 < 126 then 0 elsif L7 = 126 then 2 else 8);
            Need : constant Natural := 2 + Ext;  --  server frames: no mask
            Rest : constant String := Pipe_Read_Exact (Need - 2, Deadln);
            Full : constant String := Hdr2 & Rest;
            H    : Tedex_Ws.Frame_Header;
            Ok   : Boolean;
         begin
            Tedex_Ws.Decode_Header (Full, H, Ok, Require_Mask => False);
            if not Ok then
               raise Net_Error with "bad frame";
            end if;
            declare
               Pay : constant String := Pipe_Read_Exact (H.Pay_Len, Deadln);
            begin
               case H.Opcode is
                  when 8 =>
                     begin
                        Ws_Pipe_Send ("", 8);
                     exception
                        when Net_Error => null;
                     end;
                     raise Net_Error with "closed";
                  when 9 =>
                     Ws_Pipe_Send (Pay, 10);
                  when 10 =>
                     if Mgr_Pongs_Seen < Natural'Last then
                        Mgr_Pongs_Seen := Mgr_Pongs_Seen + 1;
                     end if;
                  when 0 =>
                     if not Started then
                        raise Net_Error with "unexpected continuation";
                     end if;
                     if Length (Msg) > Tedex_Ws.Msg_Cap - Pay'Length then
                        raise Net_Error with "message too big";
                     end if;
                     Append (Msg, Pay);
                     if H.Fin then
                        Payload := Msg;
                        return;
                     end if;
                  when 1 | 2 =>
                     if Started then
                        raise Net_Error with "interleaved message";
                     end if;
                     Started := True;
                     Msg := To_Unbounded_String (Pay);
                     if H.Fin then
                        Payload := Msg;
                        return;
                     end if;
                  when others =>
                     raise Net_Error with "bad opcode";
               end case;
            end;
         end;
      end loop;
   end Ws_Pipe_Recv_Message;

   function Ws_Pipe_Recv_Line (Timeout : Duration := 3_600.0) return String is
      P : Unbounded_String;
   begin
      Ws_Pipe_Recv_Message (Timeout, P);
      return To_String (P);
   end Ws_Pipe_Recv_Line;

   procedure Lower_In_Place (S : in out String) is
   begin
      for I in S'Range loop
         if S (I) in 'A' .. 'Z' then
            S (I) := Character'Val (Character'Pos (S (I)) + 32);
         end if;
      end loop;
   end Lower_In_Place;

   function Trim_Copy (S : String) return String is
      A : Integer := S'First;
      B : Integer := S'Last;
   begin
      while A <= S'Last and then (S (A) = ' ' or S (A) = ASCII.HT) loop
         A := A + 1;
      end loop;
      while B >= A and then (S (B) = ' ' or S (B) = ASCII.HT
                             or S (B) = ASCII.CR or S (B) = ASCII.LF) loop
         B := B - 1;
      end loop;
      if A > B then
         return "";
      end if;
      declare
         R : String (1 .. B - A + 1);
      begin
         R := S (A .. B);
         return R;
      end;
   end Trim_Copy;

   procedure Validate_Handshake (Resp, Want : String) is
   begin
      if Resp'Length < 12
        or else (Resp (Resp'First .. Resp'First + 11) /= "HTTP/1.1 101"
                 and then Resp (Resp'First .. Resp'First + 11) /= "HTTP/1.0 101")
      then
         raise Net_Error with "handshake rejected";
      end if;
      declare
         Pos   : Integer := Resp'First;
         Found : Boolean := False;
      begin
         while Pos <= Resp'Last loop
            declare
               Eol : Integer := Pos;
            begin
               while Eol <= Resp'Last and then Resp (Eol) /= ASCII.LF loop
                  Eol := Eol + 1;
               end loop;
               declare
                  Ln : constant String :=
                    Resp (Pos .. Integer'Min (Eol, Resp'Last));
               begin
                  for I in Ln'Range loop
                     if Ln (I) = ':' then
                        declare
                           Nm : constant String :=
                             (if I = Ln'First then ""
                              else Trim_Copy (Ln (Ln'First .. I - 1)));
                           Val : constant String :=
                             (if I = Ln'Last then ""
                              else Trim_Copy (Ln (I + 1 .. Ln'Last)));
                           Low : String (1 .. Integer'Max (Nm'Length, 1));
                        begin
                           if Nm'Length > 0 then
                              Low (1 .. Nm'Length) := Nm;
                           end if;
                           Lower_In_Place
                             (Low (1 .. Integer'Max (Nm'Length, 1)));
                           if Nm'Length = 20
                             and then Low (1 .. 20) = "sec-websocket-accept"
                             and then Val = Want
                           then
                              Found := True;
                           end if;
                        end;
                        exit;
                     end if;
                  end loop;
               end;
               Pos := Eol + 1;
            end;
         end loop;
         if not Found then
            raise Net_Error with "bad accept key";
         end if;
      end;
   end Validate_Handshake;

   function Tail_Is_Blank (S : Unbounded_String) return Boolean is
      L : constant Natural := Length (S);
   begin
      if L < 4 then
         return False;
      end if;
      declare
         T : constant String := Slice (S, L - 3, L);
      begin
         return T = ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF;
      end;
   end Tail_Is_Blank;

   procedure Ws_Pipe_Handshake (Host, Path, Key : String) is
      use Ada.Calendar;
      Deadln : constant Time := Clock + 20.0;
      Req : constant String :=
        "GET " & Path & " HTTP/1.1" & ASCII.CR & ASCII.LF
        & "Host: " & Host & ASCII.CR & ASCII.LF
        & "Upgrade: websocket" & ASCII.CR & ASCII.LF
        & "Connection: Upgrade" & ASCII.CR & ASCII.LF
        & "Sec-WebSocket-Key: " & Key & ASCII.CR & ASCII.LF
        & "Sec-WebSocket-Version: 13" & ASCII.CR & ASCII.LF
        & ASCII.CR & ASCII.LF;
      Resp : Unbounded_String := Null_Unbounded_String;
      Want : constant String := Tedex_Ws.Accept_Key (Key);
   begin
      Pipe_Send_All (Req);
      --  Byte at a time: stop exactly at the blank line so nothing
      --  past it is swallowed (a fixed 1024 chunk would hang here when
      --  the response is shorter than the chunk).
      loop
         exit when Length (Resp) > 8_192;
         declare
            B : constant String := Pipe_Read_Exact (1, Deadln);
         begin
            Append (Resp, B);
            exit when Length (Resp) >= 4
              and then Tail_Is_Blank (Resp);
         end;
      end loop;
      Validate_Handshake (To_String (Resp), Want);
   end Ws_Pipe_Handshake;

   --  Transport dispatch ------------------------------------------

   procedure Parse_Ws_Url (Url    : String;
                           Secure : out Boolean;
                           WHost  : out Unbounded_String;
                           WPort  : out Integer;
                           WPath  : out Unbounded_String) is
      Rest : Integer;
   begin
      Secure := False;
      WHost := Null_Unbounded_String;
      WPort := 80;
      WPath := To_Unbounded_String ("/tedex");
      if Url'Length > 5 and then Url (Url'First .. Url'First + 4) = "ws://" then
         Rest := Url'First + 5;
      elsif Url'Length > 6 and then Url (Url'First .. Url'First + 5) = "wss://" then
         Secure := True;
         WPort := 443;
         Rest := Url'First + 6;
      else
         raise Constraint_Error with "bad ws url";
      end if;
      declare
         Slash : Integer := Rest;
         Colon : Integer := -1;
      begin
         while Slash <= Url'Last and then Url (Slash) /= '/' loop
            if Url (Slash) = ':' and then Colon < 0 then
               Colon := Slash;
            end if;
            Slash := Slash + 1;
         end loop;
         if Colon > 0 then
            WHost := To_Unbounded_String (Url (Rest .. Colon - 1));
            declare
               Ps : constant String := Url (Colon + 1 .. Slash - 1);
            begin
               WPort := Integer'Value (Ps);
            end;
         else
            WHost := To_Unbounded_String (Url (Rest .. Slash - 1));
         end if;
         if Slash <= Url'Last then
            WPath := To_Unbounded_String (Url (Slash .. Url'Last));
         end if;
      end;
      if Length (WHost) = 0 or WPort not in 1 .. 65_535 then
         raise Constraint_Error with "bad ws url";
      end if;
   exception
      when Constraint_Error =>
         raise Constraint_Error with "bad ws url";
   end Parse_Ws_Url;

   function Ws_Key return String is
      Raw : constant String (1 .. 16) := Rand_Bytes (16);
   begin
      return Tedex_B64.Encode (Raw);
   end Ws_Key;

   procedure Transport_Connect is
      use Interfaces.C;
   begin
      Clear_Streams;
      if Length (Ws_Url) = 0 then
         T := (Kind => T_Raw, Sock => Connect_Sock (To_String (Host), Port),
               Rfd => -1, Wfd => -1, Pid => -1,
               Ws_Host => Null_Unbounded_String,
               Ws_Path => Null_Unbounded_String);
         return;
      end if;
      declare
         Secure : Boolean;
         Hst    : Unbounded_String;
         Prt    : Integer;
         Pth    : Unbounded_String;
         Key    : constant String := Ws_Key;
      begin
         Parse_Ws_Url (To_String (Ws_Url), Secure, Hst, Prt, Pth);
         if not Secure then
            declare
               S : constant Socket_Type :=
                 Connect_Sock (To_String (Hst), Prt);
            begin
               Ws_Client_Handshake (S, To_String (Hst), To_String (Pth), Key);
               T := (Kind => T_Ws_Sock, Sock => S,
                     Rfd => -1, Wfd => -1, Pid => -1,
                     Ws_Host => Hst, Ws_Path => Pth);
            end;
         else
            declare
               Hp   : Interfaces.C.Strings.chars_ptr :=
                 Interfaces.C.Strings.New_String (To_String (Hst));
               R, W, P : aliased Interfaces.C.int;
               Rc   : Interfaces.C.int;
            begin
               Rc := Tedex_Tls.Tls_Open
                 (Hp, Interfaces.C.int (Prt),
                  R'Access, W'Access, P'Access);
               Interfaces.C.Strings.Free (Hp);
               if Rc /= 0 then
                  raise Net_Error with "tls connect failed";
               end if;
               T := (Kind => T_Ws_Pipe, Sock => T.Sock,
                     Rfd => R, Wfd => W, Pid => P,
                     Ws_Host => Hst, Ws_Path => Pth);
               Ws_Pipe_Handshake (To_String (Hst), To_String (Pth), Key);
            end;
         end if;
      end;
   end Transport_Connect;

   procedure TClose is
      use Interfaces.C;
      Dummy : Interfaces.C.int;
      pragma Unreferenced (Dummy);
   begin
      case T.Kind is
         when T_Raw | T_Ws_Sock =>
            Close_Quiet (T.Sock);
         when T_Ws_Pipe =>
            --  Kill the openssl child first: a lingering s_client
            --  holds the TLS session open, so the server would never
            --  see EOF (attach hang + "device busy" ghosts on wss).
            Dummy := Tedex_Tls.Tls_Kill (T.Pid);
            Dummy := Tedex_Tls.Tls_Close_Fd (T.Wfd);
            Dummy := Tedex_Tls.Tls_Close_Fd (T.Rfd);
            Dummy := Tedex_Tls.Tls_Reap (T.Pid);
      end case;
      T.Pid := -1;
      Clear_Streams;
   end TClose;

   procedure MSend (Data : String) is
   begin
      case T.Kind is
         when T_Raw =>
            Send_Line (T.Sock, Data);
         when T_Ws_Sock =>
            Ws_Send_Line (T.Sock, Data, Masked => True);
         when T_Ws_Pipe =>
            Ws_Pipe_Send (Data, 2);
      end case;
   end MSend;

   function MRecv (Timeout : Duration := 3_600.0) return String is
   begin
      case T.Kind is
         when T_Raw =>
            return Recv_Line (T.Sock, Timeout);
         when T_Ws_Sock =>
            return Ws_Recv_Line (T.Sock, Timeout,
                                 Masked_Replies => True,
                                 Masked_Expected => False);
         when T_Ws_Pipe =>
            return Ws_Pipe_Recv_Line (Timeout);
      end case;
   end MRecv;

   Dbg_File : Ada.Text_IO.File_Type;
   Dbg_Open : Boolean := False;

   function Hex_Of (Data : String) return String is
      H : constant String := "0123456789abcdef";
      R : String (1 .. Data'Length * 2);
   begin
      for I in Data'Range loop
         R (2 * (I - Data'First) + 1) :=
           H (Character'Pos (Data (I)) / 16 + 1);
         R (2 * (I - Data'First) + 2) :=
           H (Character'Pos (Data (I)) mod 16 + 1);
      end loop;
      return R;
   end Hex_Of;

   --  Byte-level trace for forensics (opt-in only). Logs what this side
   --  sends to / receives from the network with a timestamp; never alters
   --  bytes and never fails the session. Enable with TEDEX_DEBUG_IO=1,
   --  file via TEDEX_DEBUG_LOG (default /tmp/tedex_io.log).
   procedure Dbg_Put (Dir : String; Data : String) is
      use Ada.Text_IO;
      On : constant Boolean :=
        (Ada.Environment_Variables.Value ("TEDEX_DEBUG_IO", "0") = "1");
   begin
      if not On then
         return;
      end if;
      if not Dbg_Open then
         declare
            Path : constant String :=
              Ada.Environment_Variables.Value
                ("TEDEX_DEBUG_LOG", "/tmp/tedex_io.log");
         begin
            Open (Dbg_File, Append_File, Path);
         exception
            when others =>
               begin
                  Create (Dbg_File, Append_File, Path);
               exception
                  when others =>
                     return;
               end;
         end;
         Dbg_Open := True;
      end if;
      Put_Line (Dbg_File,
        Duration'Image (Ada.Calendar.Seconds (Ada.Calendar.Clock))
        & " " & Dir & Integer'Image (Data'Length) & ":" & Hex_Of (Data));
      Flush (Dbg_File);
   exception
      when others =>
         null;
   end Dbg_Put;

   procedure MSend_Frame (Data : String) is
   begin
      case T.Kind is
         when T_Ws_Sock =>
            Ws_Send (T.Sock, Data, 2, Masked => True);
         when T_Ws_Pipe =>
            Ws_Pipe_Send (Data, 2);
         when T_Raw =>
            raise Program_Error with "no framing on raw transport";
      end case;
   end MSend_Frame;

   procedure MSend_Ping is
   begin
      case T.Kind is
         when T_Ws_Sock =>
            Ws_Send (T.Sock, "", 9, Masked => True);
         when T_Ws_Pipe =>
            Ws_Pipe_Send ("", 9);
         when T_Raw =>
            null;
      end case;
   end MSend_Ping;

   --  Receive with keepalive: on idle timeout, ping (WS) and keep waiting.
   --  Fatal errors propagate as Net_Error.
   function MRecv_Or_Ping (Timeout : Duration) return String is
      use Ada.Calendar;
      Deadln : constant Time := Clock + Timeout;
   begin
      loop
         declare
            Left : constant Duration := Deadln - Clock;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            if T.Kind = T_Raw then
               return MRecv (Left);
            else
               return MRecv (Duration'Min (Left, 30.0));
            end if;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  raise;
               end if;
               exit when (Deadln - Clock) <= 0.0;
               MSend_Ping;
         end;
      end loop;
      raise Net_Error with "timeout";  --  unreachable
   end MRecv_Or_Ping;

   procedure MClose_Send is
   begin
      case T.Kind is
         when T_Ws_Sock =>
            begin
               Ws_Send (T.Sock, "", 8, Masked => True);
            exception
               when Net_Error => null;
            end;
         when T_Ws_Pipe =>
            begin
               Ws_Pipe_Send ("", 8);
            exception
               when Net_Error => null;
            end;
         when T_Raw =>
            null;
      end case;
   end MClose_Send;


   --  Shell + attach over message transports ----------------------

   --  Shell over message transports ----------------------

   function Raw_Recv_Chunk (Sock    : Socket_Type;
                            Timeout : Duration) return String is
      Chunk  : Ada.Streams.Stream_Element_Array (1 .. 32_768);
      Last   : Ada.Streams.Stream_Element_Offset;
   begin
      if not Wait_Readable (Sock, Timeout) then
         raise Net_Error with "timeout";
      end if;
      Receive_Socket (Sock, Chunk, Last);
      if Last < Chunk'First then
         raise Net_Error with "closed";
      end if;
      declare
         S : String (1 .. Natural (Last - Chunk'First + 1));
      begin
         for I in S'Range loop
            S (I) := Character'Val
              (Chunk (Chunk'First + Ada.Streams.Stream_Element_Offset (I - 1)));
         end loop;
         return S;
      end;
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Raw_Recv_Chunk;

   procedure Pipe_Fill (Timeout : Duration) is
      use Interfaces.C;
      Tmp : aliased String (1 .. 4_096);
      Ms  : Integer := 0;
      Rc  : Interfaces.C.int;
   begin
      if Timeout > 0.0 then
         Ms := Integer (Timeout * 1_000.0);
         if Ms > 5_000 then
            Ms := 5_000;
         elsif Ms < 0 then
            Ms := 0;
         end if;
      end if;
      Rc := Tedex_Tls.Fd_Read_Timeout
        (T.Rfd, Tmp'Address, Tmp'Length, Interfaces.C.int (Ms));
      if Rc > 0 then
         Append (Pipe_Raw, Tmp (1 .. Natural (Rc)));
      elsif Rc = 0 then
         raise Net_Error with "closed";
      elsif Rc = -3 or Rc = -2 then
         null;  --  no data yet; bytes (if any) stay buffered
      else
         raise Net_Error with "socket error";
      end if;
   end Pipe_Fill;

   procedure Sock_Fill (Timeout : Duration) is
      Chunk : Stream_Element_Array (1 .. 32_768);
      Last  : Stream_Element_Offset;
   begin
      if not Wait_Readable (T.Sock, Timeout) then
         return;
      end if;
      Receive_Socket (T.Sock, Chunk, Last);
      if Last < Chunk'First then
         raise Net_Error with "closed";
      end if;
      declare
         S : String (1 .. Natural (Last - Chunk'First + 1));
      begin
         for I in S'Range loop
            S (I) := Character'Val
              (Chunk (Chunk'First + Stream_Element_Offset (I - 1)));
         end loop;
         Append (Sock_Raw, S);
      end;
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Sock_Fill;

   --  Buffered WS frame reader: peek, validate, then consume ----------
   --  Bytes are NEVER removed from the buffer until a full frame
   --  (header + payload) is present, so a poll timeout mid-frame loses
   --  nothing and the next poll simply resumes filling.
   procedure Ws_Recv_NB (Is_Pipe : Boolean;
                         Timeout : Duration;
                         Payload : out Unbounded_String;
                         Got_It  : out Boolean)
   is
      use Ada.Calendar;
      Deadln : constant Time := Clock + Timeout;

      procedure Ensure (N : Natural; Enough : out Boolean) is
      begin
         loop
            if (if Is_Pipe then Length (Pipe_Raw) >= N
                else Length (Sock_Raw) >= N)
            then
               Enough := True;
               return;
            end if;
            exit when Clock >= Deadln;
            if Is_Pipe then
               Pipe_Fill (Deadln - Clock);
            else
               Sock_Fill (Deadln - Clock);
            end if;
         end loop;
         Enough := (if Is_Pipe then Length (Pipe_Raw) >= N
                    else Length (Sock_Raw) >= N);
      end Ensure;

      function Peek (Low, High : Positive) return String is
      begin
         if Is_Pipe then
            return Slice (Pipe_Raw, Low, High);
         else
            return Slice (Sock_Raw, Low, High);
         end if;
      end Peek;

      procedure Drop (N : Natural) is
      begin
         if Is_Pipe then
            if Length (Pipe_Raw) <= N then
               Pipe_Raw := Null_Unbounded_String;
            else
               Pipe_Raw := To_Unbounded_String
                 (Slice (Pipe_Raw, N + 1, Length (Pipe_Raw)));
            end if;
         else
            if Length (Sock_Raw) <= N then
               Sock_Raw := Null_Unbounded_String;
            else
               Sock_Raw := To_Unbounded_String
                 (Slice (Sock_Raw, N + 1, Length (Sock_Raw)));
            end if;
         end if;
      end Drop;

   begin
      Payload := Null_Unbounded_String;
      Got_It  := False;
      loop
         declare
            Ech : Boolean;
         begin
            Ensure (2, Ech);
            if not Ech then
               return;  --  no header yet; everything kept
            end if;
            declare
               H0   : constant String := Peek (1, 2);
               L7   : constant Natural := Character'Pos (H0 (2)) mod 128;
               Ext  : constant Natural :=
                 (if L7 < 126 then 0 elsif L7 = 126 then 2 else 8);
               Need : constant Natural := 2 + Ext;
            begin
               Ensure (Need, Ech);
               if not Ech then
                  return;  --  partial header kept
               end if;
               declare
                  Hdr : constant String (1 .. Need) := Peek (1, Need);
                  H   : Tedex_Ws.Frame_Header;
                  Ok  : Boolean;
               begin
                  Tedex_Ws.Decode_Header
                    (Hdr, H, Ok, Require_Mask => False);
                  if not Ok then
                     raise Net_Error with "bad frame";
                  end if;
                  Ensure (Need + H.Pay_Len, Ech);
                  if not Ech then
                     return;  --  partial frame kept
                  end if;
                  declare
                     Pay : Unbounded_String := Null_Unbounded_String;
                  begin
                     if H.Pay_Len > 0 then
                        Pay := To_Unbounded_String
                          (Peek (Need + 1, Need + H.Pay_Len));
                     end if;
                     Drop (Need + H.Pay_Len);
                     case H.Opcode is
                        when 8 =>
                           begin
                              if Is_Pipe then
                                 Ws_Pipe_Send ("", 8);
                              else
                                 Ws_Send (T.Sock, "", 8, Masked => True);
                              end if;
                           exception
                              when Net_Error => null;
                           end;
                           raise Net_Error with "closed";
                        when 9 =>
                           if Is_Pipe then
                              Ws_Pipe_Send (To_String (Pay), 10);
                           else
                              Ws_Send (T.Sock, To_String (Pay), 10,
                                       Masked => True);
                           end if;
                        when 10 =>
                           if Mgr_Pongs_Seen < Natural'Last then
                              Mgr_Pongs_Seen := Mgr_Pongs_Seen + 1;
                           end if;
                        when 0 =>
                           if not Frag_On then
                              raise Net_Error with "unexpected continuation";
                           end if;
                           if Length (Frag_Msg)
                             > Tedex_Ws.Msg_Cap - Length (Pay)
                           then
                              raise Net_Error with "message too big";
                           end if;
                           Append (Frag_Msg, Pay);
                           if H.Fin then
                              Payload := Frag_Msg;
                              Got_It  := True;
                              Frag_Msg := Null_Unbounded_String;
                              Frag_On  := False;
                              return;
                           end if;
                        when 1 | 2 =>
                           if Frag_On then
                              raise Net_Error with "interleaved message";
                           end if;
                           Frag_On  := True;
                           Frag_Msg := Pay;
                           if H.Fin then
                              Payload := Frag_Msg;
                              Got_It  := True;
                              Frag_Msg := Null_Unbounded_String;
                              Frag_On  := False;
                              return;
                           end if;
                        when others =>
                           raise Net_Error with "bad opcode";
                     end case;
                  end;
               end;
            end;
         end;
      end loop;
   end Ws_Recv_NB;

   procedure Run_Shell_Ws (Clean : out Boolean;
                           Cols  : Natural := 0;
                           Rows  : Natural := 0) is
      H        : Tedex_Shell.Handle;
   begin
      Clean := False;
      Tedex_Shell.Spawn (H);
      Tedex_Shell.Set_Size (H, Cols, Rows);
      --  NOTE: rc-file TMOUT is neutralized inside the spawn itself
      --  (~/.tedex_rc, see tlswrap.c): nothing is typed into the
      --  shell here, so the session stays byte-clean and the pty
      --  termios is never touched while bash initializes.
      loop
         begin
            declare
               P   : Unbounded_String;
               Got : Boolean;
            begin
               Ws_Recv_NB ((T.Kind = T_Ws_Pipe), 0.001, P, Got);
               if Got then
                  Dbg_Put ("D", To_String (P));
                  Tedex_Shell.Send (H, To_String (P));
               end if;
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  Tedex_Shell.Close (H);
                  return;  --  transport broke: not clean
               end if;
            when Tedex_Shell.Shell_Error =>
               Tedex_Shell.Close (H);
               return;  --  transport ok but shell path broken: not clean
         end;
         begin
            declare
               Outgoing : constant String := Tedex_Shell.Poll (H);
            begin
               if Outgoing /= "" then
                  MSend_Frame (Outgoing);
                  loop
                     declare
                        Extra : constant String := Tedex_Shell.Poll (H, 0);
                     begin
                        exit when Extra = "";
                        MSend_Frame (Extra);
                     end;
                  end loop;
               end if;
            end;
         exception
            when Tedex_Shell.Shell_Error =>
               exit;  --  shell exited (drained): clean
            when Net_Error =>
               Tedex_Shell.Close (H);
               return;  --  transport broke mid-send: not clean
         end;
      end loop;
      Tedex_Shell.Close (H);
      Clean := True;
   end Run_Shell_Ws;

   procedure Run_Shell_Raw (Clean : out Boolean;
                            Cols  : Natural := 0;
                            Rows  : Natural := 0) is
      H        : Tedex_Shell.Handle;
   begin
      Clean := False;
      Tedex_Shell.Spawn (H);
      Tedex_Shell.Set_Size (H, Cols, Rows);
      --  Same as Run_Shell_Ws: TMOUT is handled inside the spawn.
      loop
         begin
            declare
               Incoming : constant String := Raw_Recv_Chunk (T.Sock, 0.001);
            begin
               Dbg_Put ("D", Incoming); Tedex_Shell.Send (H, Incoming);
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  Tedex_Shell.Close (H);
                  return;
               end if;
            when Tedex_Shell.Shell_Error =>
               Tedex_Shell.Close (H);
               return;
         end;
         begin
            declare
               Outgoing : constant String := Tedex_Shell.Poll (H);
            begin
               if Outgoing /= "" then
                  Tedex_Net.Send_Data (T.Sock, Outgoing);
                  loop
                     declare
                        Extra : constant String := Tedex_Shell.Poll (H, 0);
                     begin
                        exit when Extra = "";
                        Tedex_Net.Send_Data (T.Sock, Extra);
                     end;
                  end loop;
               end if;
            end;
         exception
            when Tedex_Shell.Shell_Error =>
               exit;
            when Net_Error =>
               Tedex_Shell.Close (H);
               return;
         end;
      end loop;
      Tedex_Shell.Close (H);
      Clean := True;
   end Run_Shell_Raw;

   procedure Attach_Ws is
      use Ada.Calendar;
      use Interfaces.C;
      Out_Buf  : aliased String (1 .. 4_096);
      Dummy    : Interfaces.C.int;
      Last_Traffic : Time := Clock;
      Stdin_Eof    : Boolean := False;
      --  Predictive local echo (Mosh-style, opt-out TEDEX_NO_PREDICT=1):
      --  instant display of printable keystrokes, Enter newlines and
      --  backspace erases + suppression of their remote pty echoes.
      --  ESC/other control never predicted (vim/arrows safe); prediction
      --  auto-suspends on password prompts (see Predict_Echo).
      --  Pending expires after 2s (no-echo mode), cap 1024. Backspace is
      --  predicted only while Line_Printables > 0 (chars we KNOW sit on
      --  the current unsubmitted line); erase echoes are swallowed via
      --  Erase_Credit (readline BS+ESC[K or kernel BS+space+BS), so
      --  Pending itself is never touched by erases.
      Pending : Unbounded_String := Null_Unbounded_String;
      Pending_Since : Time := Clock;
      Erase_Credit : Natural := 0;
      Erase_Since : Time := Clock;
      Erase_Half : Natural range 0 .. 2 := 0;
      Erase_Frag_At : Time := Clock;
      Line_Printables : Natural := 0;
      Last_Ended_CR : Boolean := False;
      Predict_Suspended : Boolean := False;
      --  Full-screen takeover (screen/vim/tmux/nano/htop/less switch the
      --  pty to raw + alternate screen): line-echo prediction is then
      --  meaningless, so prediction and stripping pause until the app
      --  leaves. Tracked from the standard smcup/rmcup sequences, with an
      --  8-byte tail so a split sequence is still caught.
      Fullscreen : Boolean := False;
      Fs_Tail : Unbounded_String := Null_Unbounded_String;
      Predict_On : constant Boolean :=
        (Ada.Environment_Variables.Value ("TEDEX_NO_PREDICT", "0") /= "1");
      pragma Unreferenced (Dummy);
      function Is_Predict_Byte (B : Character) return Boolean is
        (Character'Pos (B) >= 32 and Character'Pos (B) /= 127
         and Character'Pos (B) /= 27);
      procedure Predict_Echo (Chunk : String) is
         Run_Start : Integer := -1;
         procedure Flush_Run (Last : Integer) is
         begin
            if Run_Start >= 0 then
               declare
                  Run : constant String := Chunk (Run_Start .. Last);
               begin
                  Dummy := Tedex_Tls.Fd_Write_All
                    (1, Run'Address, Interfaces.C.int (Run'Length));
                  if Length (Pending) < 1024 then
                     Append (Pending, Run);
                     if Length (Pending) = Run'Length then
                        Pending_Since := Clock;
                     end if;
                  end if;
                  Line_Printables :=
                    Natural'Min (Line_Printables + Run'Length, 4096);
               end;
               Run_Start := -1;
            end if;
         end Flush_Run;
         procedure Predict_Newline is
            NL : constant String (1 .. 2) := [ASCII.CR, ASCII.LF];
         begin
            Dummy := Tedex_Tls.Fd_Write_All
              (1, NL'Address, Interfaces.C.int (NL'Length));
            if Length (Pending) < 1022 then
               Append (Pending, NL);
               if Length (Pending) = NL'Length then
                  Pending_Since := Clock;
               end if;
            end if;
            Line_Printables := 0;
            Predict_Suspended := False;
         end Predict_Newline;
         procedure Predict_Erase is
            Er : constant String (1 .. 4) :=
              [ASCII.BS, ASCII.ESC, '[', 'K'];
         begin
            Dummy := Tedex_Tls.Fd_Write_All
              (1, Er'Address, Interfaces.C.int (Er'Length));
            Erase_Credit := Natural'Min (Erase_Credit + 1, 64);
            if Erase_Credit = 1 then
               Erase_Since := Clock;
            end if;
            if Line_Printables > 0 then
               Line_Printables := Line_Printables - 1;
            end if;
         end Predict_Erase;
         function Has_Newline (C : String) return Boolean is
         begin
            for Ch of C loop
               if Ch = ASCII.CR or Ch = ASCII.LF then
                  return True;
               end if;
            end loop;
            return False;
         end Has_Newline;
      begin
         if not Predict_On or Chunk'Length = 0 then return; end if;
         if Fullscreen then
            --  App owns the screen: show nothing locally, believe nothing.
            Line_Printables := 0;
            Last_Ended_CR := False;
            Dbg_Put ("P", "skip-fs");
            return;
         end if;
         if Predict_Suspended then
            --  Password prompt active: stay dark until the user submits
            --  the line (so secrets are never shown locally). A line
            --  abort still voids the erase belief even while dark.
            if Has_Newline (Chunk) then
               Predict_Suspended := False;
            else
               for Ch of Chunk loop
                  if Ch = ASCII.ETX or Ch = ASCII.NAK then
                     Line_Printables := 0;
                     exit;
                  end if;
               end loop;
               Last_Ended_CR := False;
               return;
            end if;
         end if;
         for I in Chunk'Range loop
            if Chunk (I) = ASCII.CR or Chunk (I) = ASCII.LF then
               --  Enter/paste newline: show CRLF at once so next typing
               --  starts on a fresh line; collapse CRLF pair to one
               --  (Last_Ended_CR persists across chunks).
               Flush_Run (I - 1);
               if Chunk (I) = ASCII.LF and Last_Ended_CR then
                  Last_Ended_CR := False;
               else
                  Predict_Newline;
                  Last_Ended_CR := (Chunk (I) = ASCII.CR);
               end if;
            elsif Chunk (I) = ASCII.DEL or Chunk (I) = ASCII.BS then
               Flush_Run (I - 1);
               Last_Ended_CR := False;
               if Line_Printables > 0 and Erase_Credit < 64 then
                  Predict_Erase;
               end if;
            elsif Chunk (I) = ASCII.ETX or Chunk (I) = ASCII.NAK then
               --  Ctrl+C / Ctrl+U abort or kill the server-side line, so
               --  our erase belief is void from here: further backspaces
               --  must not eat prompt text locally (in-flight echoes and
               --  erase credits are left alone, they still arrive).
               Flush_Run (I - 1);
               Last_Ended_CR := False;
               Line_Printables := 0;
            elsif Is_Predict_Byte (Chunk (I)) then
               if Run_Start < 0 then Run_Start := I; end if;
               Last_Ended_CR := False;
            else
               Flush_Run (I - 1);
               Last_Ended_CR := False;
            end if;
         end loop;
         Flush_Run (Chunk'Last);
      end Predict_Echo;
      procedure Consume_Echo (S : in out Unbounded_String) is
         function Low_Match (V, Key : String) return Boolean is
            --  Case-insensitive substring search (for password prompts).
         begin
            if Key'Length = 0 or else V'Length < Key'Length then
               return False;
            end if;
            for I in V'First .. V'Last - Key'Length + 1 loop
               declare
                  Hit : Boolean := True;
               begin
                  for J in 0 .. Key'Length - 1 loop
                     declare
                        A : Character := V (I + J);
                        B : Character := Key (Key'First + J);
                     begin
                        if A in 'A' .. 'Z' then
                           A := Character'Val (Character'Pos (A) + 32);
                        end if;
                        if B in 'A' .. 'Z' then
                           B := Character'Val (Character'Pos (B) + 32);
                        end if;
                        if A /= B then
                           Hit := False;
                           exit;
                        end if;
                     end;
                  end loop;
                  if Hit then
                     return True;
                  end if;
               end;
            end loop;
            return False;
         end Low_Match;
      begin
         if not Predict_On or Length (S) = 0 then return; end if;
         declare
            Raw : constant String := To_String (S);
            Scan : constant String :=
              To_String (Fs_Tail) & Raw;
         begin
            --  smcup (?1049h): a full-screen app took over; rmcup (?1049l):
            --  it left. Stale line beliefs die on entry.
            if Low_Match (Scan, ASCII.ESC & "[?1049h") then
               Fullscreen := True;
               Dbg_Put ("FS", "on");
               Pending := Null_Unbounded_String;
               Line_Printables := 0;
               Erase_Credit := 0;
               Erase_Half := 0;
            end if;
            if Low_Match (Scan, ASCII.ESC & "[?1049l") then
               Fullscreen := False;
               Dbg_Put ("FS", "off");
            end if;
            if Scan'Length > 8 then
               Fs_Tail := To_Unbounded_String
                 (Scan (Scan'Last - 7 .. Scan'Last));
            else
               Fs_Tail := To_Unbounded_String (Scan);
            end if;
            --  Auto-suspend prediction while a password is asked, so the
            --  secret is never displayed locally (resumed at next Enter).
            if Low_Match (Raw, "password")
              or Low_Match (Raw, "passwd")
              or Low_Match (Raw, "passphrase")
            then
               Predict_Suspended := True;
            end if;
         end;
         --  1. swallow pty erase echoes for predicted backspaces
         if Erase_Credit > 0 then
            if Clock - Erase_Since > 2.0 then
               Erase_Credit := 0;
               Erase_Half := 0;
            else
               loop
                  exit when Erase_Credit = 0 or Length (S) = 0;
                  declare
                     Vs : constant String := To_String (S);
                     E1 : constant String :=
                       [ASCII.BS, ASCII.ESC, '[', 'K'];
                     E2 : constant String :=
                       [ASCII.BS, ' ', ASCII.BS];
                     Matched : Natural := 0;
                  begin
                     if Erase_Half = 1
                       and then Clock - Erase_Frag_At <= 1.0
                       and then Vs'Length >= 3
                       and then Vs (Vs'First .. Vs'First + 2) =
                         [ASCII.ESC, '[', 'K']
                     then
                        --  Held BS meets its ESC[K tail.
                        Matched := 3;
                        Erase_Half := 0;
                     elsif Erase_Half = 2
                       and then Clock - Erase_Frag_At <= 1.0
                       and then Vs'Length >= 1
                       and then Vs (Vs'First) = ASCII.BS
                     then
                        --  Held BS+space meets its final BS.
                        Matched := 1;
                        Erase_Half := 0;
                     else
                        Erase_Half := 0;
                     end if;
                     if Matched = 0 then
                        if Vs'Length >= 4
                          and then Vs (Vs'First .. Vs'First + 3) = E1
                        then
                           Matched := 4;
                        elsif Vs'Length >= 3
                          and then Vs (Vs'First .. Vs'First + 2) = E2
                        then
                           Matched := 3;
                        elsif Vs'Length < 4
                          and then E1 (1 .. Vs'Length) = Vs
                        then
                           --  Split erase echo: hold for the rest.
                           S := Null_Unbounded_String;
                           Erase_Half := 1;
                           Erase_Frag_At := Clock;
                           exit;
                        elsif Vs'Length < 3
                          and then E2 (1 .. Vs'Length) = Vs
                        then
                           S := Null_Unbounded_String;
                           Erase_Half := 2;
                           Erase_Frag_At := Clock;
                           exit;
                        else
                           exit;
                        end if;
                     end if;
                     if Matched > 0 then
                        if Vs'Length = Matched then
                           S := Null_Unbounded_String;
                        else
                           S := To_Unbounded_String
                             (Vs (Vs'First + Matched .. Vs'Last));
                        end if;
                        Erase_Credit := Erase_Credit - 1;
                     end if;
                  end;
               end loop;
               if Length (S) = 0 then return; end if;
            end if;
         end if;
         --  2. strip our echoed bytes (readline may prefix the message
         --  with bracketed-paste wrappers; those are real output framing
         --  so they are kept while the echo behind them is dropped).
         if Length (Pending) = 0 then return; end if;
         if Clock - Pending_Since > 2.0 then
            --  No-echo consumer (password/fullscreen app) ate the bytes:
            --  drop the echo expectation AND the line-length belief, or a
            --  later backspace would wrongly erase prompt text locally.
            Pending := Null_Unbounded_String;
            Line_Printables := 0;
            Erase_Credit := 0;
            Erase_Half := 0;
            return;
         end if;
         declare
            Ps : constant String := To_String (Pending);
            Vs : constant String := To_String (S);
            K  : Natural := 0;
         begin
            while K < Natural'Min (Vs'Length, Ps'Length)
              and then Vs (Vs'First + K) = Ps (Ps'First + K) loop
               K := K + 1;
            end loop;
            if K > 0 then
               if K >= Vs'Length and Vs'Length <= Ps'Length then
                  Pending := To_Unbounded_String
                    (Ps (Ps'First + K .. Ps'Last));
                  S := Null_Unbounded_String;
                  if Length (Pending) /= 0 then
                     Pending_Since := Clock;
                  end if;
               elsif K >= Ps'Length then
                  S := To_Unbounded_String (Vs (Vs'First + K .. Vs'Last));
                  Pending := Null_Unbounded_String;
               else
                  S := To_Unbounded_String (Vs (Vs'First + K .. Vs'Last));
                  Pending := To_Unbounded_String (Ps (Ps'First + K .. Ps'Last));
                  Pending_Since := Clock;
               end if;
               return;
            end if;
            declare
               B1 : constant String :=
                 [ASCII.ESC, '[', '?', '2', '0', '0', '4', 'l'];
               B2 : constant String :=
                 [ASCII.ESC, '[', '?', '2', '0', '0', '4', 'h'];
               Pre : Natural := 0;
               K2  : Natural := 0;
            begin
               if Vs'Length > 8
                 and then (Vs (Vs'First .. Vs'First + 7) = B1
                           or Vs (Vs'First .. Vs'First + 7) = B2)
               then
                  Pre := 8;
                  --  Readline redraws as brackets+CR ahead of the echo
                  --  itself; that CR is framing, not echoed input.
                  if Vs'Length > 8
                    and then Vs (Vs'First + 8) = ASCII.CR
                  then
                     Pre := 9;
                  end if;
               end if;
               if Pre = 0 then return; end if;
               while Pre + K2 < Vs'Length
                 and then K2 < Ps'Length
                 and then Vs (Vs'First + Pre + K2) = Ps (Ps'First + K2) loop
                  K2 := K2 + 1;
               end loop;
               if K2 = 0 then return; end if;
               if Pre + K2 >= Vs'Length and then Pre + K2 <= Vs'Length
                 and then K2 <= Ps'Length
               then
                  --  Whole tail behind the brackets was echo.
                  Pending := To_Unbounded_String
                    (Ps (Ps'First + K2 .. Ps'Last));
                  S := To_Unbounded_String
                    (Vs (Vs'First .. Vs'First + Pre - 1));
                  if Length (Pending) /= 0 then
                     Pending_Since := Clock;
                  end if;
               elsif K2 >= Ps'Length then
                  S := To_Unbounded_String
                    (Vs (Vs'First .. Vs'First + Pre - 1)
                     & Vs (Vs'First + Pre + K2 .. Vs'Last));
                  Pending := Null_Unbounded_String;
               else
                  S := To_Unbounded_String
                    (Vs (Vs'First .. Vs'First + Pre - 1)
                     & Vs (Vs'First + Pre + K2 .. Vs'Last));
                  Pending := To_Unbounded_String
                    (Ps (Ps'First + K2 .. Ps'Last));
                  Pending_Since := Clock;
               end if;
            end;
         end;
      end Consume_Echo;
   begin
      Tedex_Term.Term_Raw (1);
      Dummy := Tedex_Term.Term_Set_Nonblock (0, 1);
      loop
         begin
            declare
               P   : Unbounded_String;
               Got : Boolean;
            begin
               Ws_Recv_NB ((T.Kind = T_Ws_Pipe), 0.002, P, Got);
               if Got then
                  Dbg_Put ("R", To_String (P));
                  declare
                     S : Unbounded_String := P;
                  begin
                     Consume_Echo (S);
                     if Length (S) > 0 then
                        declare
                           Vs : constant String := To_String (S);
                        begin
                           Dummy := Tedex_Tls.Fd_Write_All
                             (1, Vs'Address, Interfaces.C.int (Vs'Length));
                        end;
                     end if;
                     Last_Traffic := Clock;
                  end;
               end if;
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  exit;
               end if;
         end;
         if not Stdin_Eof then
            declare
               Rc : constant Interfaces.C.int :=
                 Tedex_Term.Term_Read_Chunk
                   (Out_Buf'Address, Out_Buf'Length);
            begin
               if Rc > 0 then
                  declare
                     Total : Natural := Natural (Rc);
                     Extra : Interfaces.C.int;
                  begin
                     for J in 1 .. 5 loop
                        exit when Total >= Out_Buf'Length;
                        Extra := Tedex_Term.Term_Read_Chunk
                          (Out_Buf (Total + 1)'Address,
                           Interfaces.C.int (Out_Buf'Length - Total));
                        exit when Extra <= 0;
                        Total := Total + Natural (Extra);
                     end loop;
                     MSend_Frame (Out_Buf (1 .. Total));
                     Dbg_Put ("S", Out_Buf (1 .. Total));
                     Predict_Echo (Out_Buf (1 .. Total));
                     Last_Traffic := Clock;
                  end;
               elsif Rc = 0 then
                  --  No more input, but the session lives on: the shell
                  --  ends it (or silence below does).
                  Stdin_Eof := True;
               elsif Rc = -1 then
                  exit;
               end if;
            end;
         end if;
         if Stdin_Eof and then Clock - Last_Traffic > 30.0 then
            MClose_Send;
            exit;
         end if;
         if Clock - Last_Traffic > 25.0 then
            begin
               MSend_Ping;
               Last_Traffic := Clock;
            exception
               when Net_Error => exit;
            end;
         end if;
      end loop;
      --  Restore the terminal fully: Attach_Ws sets raw + nonblock.
      Dummy := Tedex_Term.Term_Set_Nonblock (0, 0);
      Tedex_Term.Term_Raw (0);
   end Attach_Ws;



   --  Device + manager --------------------------------------------

   procedure Device_Loop (U, P, D : String) is
      Done       : Boolean := False;
      Had_Error  : Boolean := False;
      Fail_Count : Natural := 0;
      Authed     : Boolean := False;

      --  Jittered exponential backoff: a fixed retry delay turns a
      --  fleet-wide outage into a synchronized thundering herd that
      --  re-hammers the server every 5 s. Caps at ~65 s, resets on
      --  every successful registration.
      procedure Fail (Msg : String) is
         Wait_Secs : Natural;
      begin
         Ada.Text_IO.Put_Line ("[" & D & "] " & Msg);
         TClose;
         if Persist then
            Fail_Count := Natural'Min (Fail_Count + 1, 6);
            Wait_Secs :=
              Natural'Min (5 * (2 ** (Fail_Count - 1)), 60);
            declare
               Rb : constant String := Rand_Bytes (1);
            begin
               Wait_Secs := Wait_Secs
                 + Character'Pos (Rb (Rb'First)) mod 6;
            exception
               when others => null;
            end;
            delay Duration (Wait_Secs);
         else
            Had_Error := True;
            Done := True;
         end if;
      end Fail;

   begin
      while not Done loop
         begin
            Authed := False;  --  set True only by a genuine OK below
            Transport_Connect;
            MSend ("AUTH device " & U & " " & P & " " & D);
            declare
               Resp : constant String := MRecv (30.0);
            begin
               if Resp'Length < 2
                 or else Resp (Resp'First .. Resp'First + 1) /= "OK"
               then
                  if Resp'Length = 15
                    and then Resp (Resp'First .. Resp'First + 14)
                               = "ERR busy, retry"
                  then
                     --  Transient store contention server-side: back
                     --  off and retry (never treat as deprovisioning).
                     TClose;
                     Fail ("server busy, retrying...");
                  else
                     Ada.Text_IO.Put_Line ("[" & D & "] " & Resp);
                     TClose;
                     Had_Error := True;
                     Done := True;  --  auth refused: never retry
                  end if;
               else
                  Authed := True;  --  genuine OK: proceed to shell wait
               end if;
            end;
            --  NOTE: a transient busy-retry must NOT fall through
            --  here (it would print a phantom "registered" and then
            --  read a closed socket): only a genuine OK sets Authed.
            if Authed and then not Done then
               Fail_Count := 0;  --  healthy again: restart backoff
               Ada.Text_IO.Put_Line ("[" & D & "] registered as " & U);
            declare
               Shell_Clean : Boolean := False;
               DCols, DRows : Natural := 0;
            begin
               loop
                  begin
                     declare
                        L : constant String := MRecv_Or_Ping (3_600.0);
                     begin
                        begin
                           if Ada.Environment_Variables.Value
                             ("TEDEX_DEBUG_KEYS") = "1"
                           then
                              Ada.Text_IO.Put_Line ("[dev] cmd: " & L);
                              Ada.Text_IO.Flush (Ada.Text_IO.Standard_Output);
                           end if;
                        exception
                           when Constraint_Error => null;
                        end;
                        if L = "PING" then
                           MSend ("PONG");
                        elsif L = "REMOVED" then
                           --  Manager removed us: stop (and uninstall in
                           --  main). Never retry, even with --persist.
                           --  Same name may register again later: nothing
                           --  is banned, only this machine stops itself.
                           Ada.Text_IO.Put_Line
                             ("[" & D & "] removed by manager"
                              & " -- uninstalling...");
                           Was_Removed := True;
                           exit;
                        elsif L'Length >= 11
                          and then L (L'First .. L'First + 10) = "SHELL_START"
                        then
                           Parse_Start_Dims (L, DCols, DRows);
                           if T.Kind = T_Raw then
                              Run_Shell_Raw (Shell_Clean, DCols, DRows);
                           else
                              Run_Shell_Ws (Shell_Clean, DCols, DRows);
                           end if;
                           exit;
                        end if;
                     end;
                  exception
                     when E : Net_Error =>
                        if Ada.Exceptions.Exception_Message (E) /= "timeout"
                        then
                           raise;
                        end if;
                        --  Hourly budget elapsed with no shell: stay online,
                        --  keep waiting on a fresh budget.
                  end;
               end loop;
               TClose;
               if Was_Removed then
                  Done := True;
               elsif not Shell_Clean then
                  --  Should not happen (shell paths set Clean), stay safe.
                  Fail ("session ended");
               else
                  --  Clean shell exit (user typed "exit" - or the shell
                  --  died on its own, e.g. TMOUT auto-logout): log it so
                  --  a mystery manager-side "session ended" is traceable.
                  Ada.Text_IO.Put_Line
                    ("[" & D & "] shell exited, re-registering"
                     & " (if unexpected, check TMOUT/exit in shell rc)");
               end if;
               --  Clean shell end: loop right back to re-register with no
               --  delay, so the device is (almost) never seen offline.
               end;
            end if;
         exception
            when Socket_Error | Host_Error | Constraint_Error =>
               Fail ("connect failed, " & (if Persist then "retry..."
                                          else "offline"));
            when Net_Error =>
               Fail ("disconnected, " & (if Persist then "retry..."
                                        else "offline"));
            when Tedex_Shell.Shell_Error =>
               Fail ("shell failed, " & (if Persist then "retry..."
                                        else "offline"));
         end;
      end loop;
      if Had_Error and then not Persist then
         GNAT.OS_Lib.OS_Exit (1);
      end if;
   end Device_Loop;

   procedure Login_Manager (U, P : String) is
   begin
      Transport_Connect;
      MSend ("AUTH manager " & U & " " & P & " -");
      declare
         Resp : constant String := MRecv (30.0);
      begin
         if Resp'Length < 2 or else Resp (Resp'First .. Resp'First + 1) /= "OK" then
            TClose;
            raise Program_Error with Resp;
         end if;
      end;
   end Login_Manager;


   procedure Manager_Loop (U, P : String) is
      use Ada.Text_IO;

      function Stripped (S : String) return String is
         A : Integer := S'First;
         B : Integer := S'Last;
      begin
         while A <= S'Last
           and then (S (A) = ' ' or S (A) = ASCII.HT or S (A) = ASCII.CR)
         loop
            A := A + 1;
         end loop;
         while B >= A
           and then (S (B) = ' ' or S (B) = ASCII.HT or S (B) = ASCII.CR)
         loop
            B := B - 1;
         end loop;
         if A > B then
            return "";
         end if;
         declare
            R : String (1 .. B - A + 1);
         begin
            R := S (A .. B);
            return R;
         end;
      end Stripped;

      function Lowered (S : String) return String is
         R : String (S'Range) := S;
      begin
         for I in R'Range loop
            if R (I) in 'A' .. 'Z' then
               R (I) := Character'Val (Character'Pos (R (I)) + 32);
            end if;
         end loop;
         return R;
      end Lowered;

      function Get_Cmd return String is
         Buf : aliased String (1 .. 1024);
         N   : constant Interfaces.C.int :=
           Tedex_Term.C_Read_Line (Buf'Address, Buf'Length);
      begin
         if N <= 0 then
            return "";
         end if;
         declare
            S : constant String := Buf (1 .. Natural (N));
         begin
            if S'Length > 0 and then S (S'Last) = ASCII.LF then
               if S'Length > 1 and then S (S'Last - 1) = ASCII.CR then
                  return S (S'First .. S'Last - 2);
               end if;
               return S (S'First .. S'Last - 1);
            end if;
            return S;
         end;
      end Get_Cmd;

      --  Prompt input with keepalive: while the manager idles at the
      --  prompt, ping the server every 25 s (an idle-looking link is
      --  otherwise reaped by middleboxes) and verify inbound pongs, so
      --  a silently dead link reports "connection lost" here instead of
      --  ambushing the next command. Raw transports have no WS framing
      --  or pong events: plain blocking read there.
      function Get_Cmd_Alive return String is
         use Ada.Calendar;
         Last_Ping : Time := Clock;
         Last_Pipe : Natural := Mgr_Pongs_Seen;
         Last_Net  : Natural := Tedex_Net.Ws_Pong_Count;
         Silent    : Natural := 0;
      begin
         if T.Kind = T_Raw then
            return Get_Cmd;
         end if;
         loop
            declare
               R : constant Interfaces.C.int :=
                 Tedex_Tls.Fd_Wait_Read (0, 1_000);
            begin
               if R = 1 then
                  return Get_Cmd;
               elsif R = -1 then
                  return Get_Cmd;  --  broken stdin poll: legacy path
               end if;
            end;
            if Clock - Last_Ping >= 25.0 then
               begin
                  declare
                     Drop : constant String := MRecv_Or_Ping (2.0);
                     pragma Unreferenced (Drop);
                  begin
                     --  Unexpected inbound traffic still proves
                     --  the link is alive; its content has no
                     --  outstanding command at the prompt.
                     Last_Pipe := Mgr_Pongs_Seen;
                     Last_Net := Tedex_Net.Ws_Pong_Count;
                     Silent := 0;
                  end;
               exception
                  when E : Net_Error =>
                     if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                        raise;
                     end if;
               end;
               MSend_Ping;
               --  Either transport's pongs (pipe for wss://, socket
               --  frames for ws://) reset the silence count.
               if Mgr_Pongs_Seen /= Last_Pipe
                 or Tedex_Net.Ws_Pong_Count /= Last_Net
               then
                  Last_Pipe := Mgr_Pongs_Seen;
                  Last_Net := Tedex_Net.Ws_Pong_Count;
                  Silent := 0;
               else
                  Silent := Silent + 1;
               end if;
               if Silent >= 4 then
                  raise Net_Error with "link dead (server silent)";
               end if;
               Last_Ping := Clock;
            end if;
         end loop;
      end Get_Cmd_Alive;

      procedure Split_Verb (Cmd : String; V, A : out Unbounded_String) is
         Sp : Integer := Cmd'First;
      begin
         while Sp <= Cmd'Last
           and then Cmd (Sp) /= ' ' and then Cmd (Sp) /= ASCII.HT
         loop
            Sp := Sp + 1;
         end loop;
         V := To_Unbounded_String (Lowered (Cmd (Cmd'First .. Sp - 1)));
         if Sp > Cmd'Last then
            A := Null_Unbounded_String;
         else
            A := To_Unbounded_String (Stripped (Cmd (Sp + 1 .. Cmd'Last)));
         end if;
      end Split_Verb;

      procedure Do_List is
      begin
         MSend ("LIST");
         declare
            Head : constant String := MRecv_Or_Ping (30.0);
            N    : Natural := 0;
         begin
         if Head'Length >= 8
           and then Head (Head'First .. Head'First + 7) = "DEVICES "
         then
            N := Parse_Count (Head (Head'First + 8 .. Head'Last));
         else
            Put_Line (Head);
         end if;
         if N = 0 then
            Put_Line ("no devices known");
         else
            Put_Line (Trimmed_Count (N) & " device(s):");
         end if;
         loop
            declare
               L : constant String := MRecv_Or_Ping (30.0);
            begin
               exit when L = "END";
               if L'Length > 7
                 and then L (L'First .. L'First + 6) = "DEVICE "
               then
                  declare
                     Rest : constant String :=
                       L (L'First + 7 .. L'Last);
                     Sp1  : Integer := Rest'First;
                  begin
                     while Sp1 <= Rest'Last and then Rest (Sp1) /= ' ' loop
                        Sp1 := Sp1 + 1;
                     end loop;
                     if Sp1 > Rest'Last then
                        Put_Line ("  - " & Rest);
                     else
                        declare
                           Id : constant String :=
                             Rest (Rest'First .. Sp1 - 1);
                           R2 : constant String :=
                             Rest (Sp1 + 1 .. Rest'Last);
                           Sp2 : Integer := R2'First;
                        begin
                           while Sp2 <= R2'Last and then R2 (Sp2) /= ' ' loop
                              Sp2 := Sp2 + 1;
                           end loop;
                           if Sp2 > R2'Last then
                              Put_Line ("  - " & Rest);
                           else
                              declare
                                 St : constant String :=
                                   R2 (R2'First .. Sp2 - 1);
                                 Info : constant String :=
                                   R2 (Sp2 + 1 .. R2'Last);
                              begin
                                 if St = "online" or St = "busy"
                                   or St = "offline"
                                 then
                                    Put_Line ("  - " & Id
                                              & " [" & St & "] " & Info);
                                 else
                                    Put_Line ("  - " & Rest);
                                 end if;
                              end;
                           end if;
                        end;
                     end if;
                  end;
               else
                  Put_Line (L);
               end if;
            end;
         end loop;
         end;
      end Do_List;

      procedure Do_Attach (Id : String) is
         Rws, Cws : aliased Interfaces.C.int := 0;
         WCols, WRows : Natural := 0;
      begin
         if Id'Length = 0 then
            Put_Line ("usage: attach <device_id>");
            return;
         end if;
         --  Report our terminal size first so the device pty matches it
         --  (tmux/full-screen need real dims; long lines wrap at the
         --  right column). Unknown/not-a-tty falls back to 80x24 rather
         --  than 0x0. Old servers answer ERR: ATTACH still proceeds.
         if C_Get_Size (Rws'Access, Cws'Access) = 0
           and then Rws >= 1 and then Rws <= 1000
           and then Cws >= 1 and then Cws <= 1000
         then
            WRows := Natural (Rws);
            WCols := Natural (Cws);
         else
            WRows := 24;
            WCols := 80;
         end if;
         MSend ("RESIZE " & Id & " "
                & Trimmed_Count (WCols) & " " & Trimmed_Count (WRows));
         declare
            RResp : constant String := MRecv_Or_Ping (30.0);
            pragma Unreferenced (RResp);
         begin
            null;  --  "OK resized", or ERR from a pre-resize server
         end;
         MSend ("ATTACH " & Id);
         declare
            Resp : constant String := MRecv_Or_Ping (60.0);
         begin
            Put_Line (Resp);
            if Resp'Length >= 8
              and then Resp (Resp'First .. Resp'First + 7) = "ATTACHED"
            then
               Flush (Standard_Output);
               if T.Kind = T_Raw then
                  declare
                     Dummy : Interfaces.C.int :=
                       Tedex_Term.Attach
                         (Interfaces.C.int (To_C (T.Sock)));
                     pragma Unreferenced (Dummy);
                  begin
                     null;
                  end;
               else
                  Attach_Ws;
               end if;
               TClose;
               Put_Line ("session ended — reconnecting...");
               Login_Manager (U, P);
            end if;
         end;
      end Do_Attach;

   begin
      Login_Manager (U, P);
      Put_Line ("manager " & U & " — type help");
      loop
         Put (U & "@tedex> ");
         Flush (Standard_Output);
         declare
            Verb : Unbounded_String;
            Arg  : Unbounded_String;
         begin
            Split_Verb (Stripped (Get_Cmd_Alive), Verb, Arg);
            if Length (Verb) = 0
              or else To_String (Verb) = "exit"
              or else To_String (Verb) = "quit"
            then
               begin
                  MSend ("QUIT");
               exception
                  when Net_Error => null;
               end;
               TClose;
               return;
            elsif To_String (Verb) = "help" then
               Put_Line ("list | attach <device_id> | remove <device_id> | "
                         & "exit");
            elsif To_String (Verb) = "list" then
               Do_List;
            elsif To_String (Verb) = "attach" then
               Do_Attach (To_String (Arg));
            elsif To_String (Verb) = "remove" then
               declare
                  Id : constant String := To_String (Arg);
               begin
                  if Id'Length = 0 then
                     Put_Line ("usage: remove <device_id>");
                  else
                     MSend ("REMOVE " & Id);
                     declare
                        Resp : constant String := MRecv_Or_Ping (30.0);
                     begin
                        Put_Line (Resp);
                     end;
                  end if;
               end;
            else
               Put_Line ("unknown: list | attach <id> | remove <id> | "
                         & "exit");
            end if;
         end;
      end loop;
   exception
      when Net_Error | Socket_Error | Host_Error =>
         begin
            TClose;
         exception
            when others => null;
         end;
         Put_Line ("connection lost");
      when Program_Error =>
         Put_Line ("login failed");
   end Manager_Loop;

   function Unit_Name_Of (Dev : String) return String is
   begin
      return "tedex-" & Dev & ".service";
   end Unit_Name_Of;

   function Unit_Dir return String is
   begin
      return Ada.Directories.Compose
        (Ada.Directories.Compose
           (Ada.Directories.Compose
              (Ada.Environment_Variables.Value ("HOME"), ".config"),
            "systemd"),
         "user");
   end Unit_Dir;

   function Safe_Dev_Name (Dev : String) return Boolean is
   begin
      return Tedex_Protocol.Valid_Token (Dev);
   end Safe_Dev_Name;

   function Which (Name : String) return String is
   begin
      if Ada.Directories.Exists ("/usr/bin/" & Name) then
         return "/usr/bin/" & Name;
      elsif Ada.Directories.Exists ("/bin/" & Name) then
         return "/bin/" & Name;
      elsif Ada.Directories.Exists ("/usr/local/bin/" & Name) then
         return "/usr/local/bin/" & Name;
      else
         return "";
      end if;
   end Which;

   function Run_Cmd (Prog : String; A1, A2, A3, A4 : String := "")
     return Integer
   is
      use GNAT.OS_Lib;
      Args : Argument_List (1 .. 4);
      Last : Natural := 0;
      Code : Integer := -1;

      procedure Push (A : String) is
      begin
         if A /= "" then
            Last := Last + 1;
            Args (Last) := new String'(A);
         end if;
      end Push;
   begin
      Push (A1);
      Push (A2);
      Push (A3);
      Push (A4);
      if Prog /= "" then
         if Last = 0 then
            declare
               Empty : Argument_List (1 .. 0);
            begin
               Code := Spawn (Prog, Empty);
            end;
         else
            Code := Spawn (Prog, Args (1 .. Last));
         end if;
      end if;
      for I in 1 .. Last loop
         Free (Args (I));
      end loop;
      return Code;
   exception
      when others =>
         return -1;
   end Run_Cmd;

   procedure Write_Unit_File (UDir, Want_By : String) is
      use Ada.Text_IO;
      Dev  : constant String := To_String (Dev_Id);
      Self : constant String :=
        Ada.Directories.Full_Name (Ada.Command_Line.Command_Name);
      Unit : constant String := Unit_Name_Of (Dev);
      F    : File_Type;
   begin
      Ada.Directories.Create_Path (UDir);
      Create (F, Out_File, Ada.Directories.Compose (UDir, Unit));
      Put_Line (F, "[Unit]");
      Put_Line (F, "Description=tedex device " & Dev);
      Put_Line (F, "After=network-online.target");
      Put_Line (F, "Wants=network-online.target");
      Put_Line (F, "");
      Put_Line (F, "[Service]");
      Put_Line (F, "Environment=TERM=xterm-256color");
      Put_Line (F, "ExecStart=" & Self
                & " -s " & To_String (Host)
                & " -p " & Trimmed_Count (Port)
                & (if Length (Ws_Url) > 0
                   then " --ws " & To_String (Ws_Url) else "")
                & " -c " & To_String (User) & " " & To_String (Pass)
                & " --name " & Dev & " --persist");
      Put_Line (F, "Restart=always");
      Put_Line (F, "RestartSec=5");
      Put_Line (F, "");
      Put_Line (F, "[Install]");
      Put_Line (F, "WantedBy=" & Want_By);
      Close (F);
      declare
         Chmod : constant String := Which ("chmod");
         Rc    : Integer;
         pragma Unreferenced (Rc);
      begin
         if Chmod = "" then
            Put_Line (Standard_Error, "ERR: chmod not found");
            return;
         end if;
         Rc := Run_Cmd (Chmod, "600",
                        Ada.Directories.Compose (UDir, Unit), "");
      end;
   end Write_Unit_File;

   procedure Do_Install_Service is
      use Ada.Text_IO;
      Dev  : constant String := To_String (Dev_Id);
      Home : constant String :=
        Ada.Environment_Variables.Value ("HOME", "");
      Unit : constant String := Unit_Name_Of (Dev);
      Dst  : constant String :=
        (if Length (Ws_Url) > 0 then To_String (Ws_Url)
         else To_String (Host) & ":" & Trimmed_Count (Port));
   begin
      if not Safe_Dev_Name (Dev) then
         Put_Line (Standard_Error,
           "ERR: --name must be 1..64 chars [alnum _ - .] for -r");
         return;
      end if;
      if C_Geteuid = 0 then
         --  Root: system unit (no user bus needed, runs at boot).
         Write_Unit_File ("/etc/systemd/system", "multi-user.target");
         declare
            Ctl : constant String := Which ("systemctl");
         begin
            if Ctl = "" then
               Put_Line (Standard_Error,
                 "ERR: systemctl not found; unit file kept at "
                 & "/etc/systemd/system/" & Unit);
               return;
            end if;
            if Run_Cmd (Ctl, "daemon-reload", "", "") /= 0 then
               Put_Line (Standard_Error,
                 "ERR: systemctl daemon-reload failed (no systemd? "
                 & "use --persist with container restart policy instead; "
                 & "unit file kept)");
               return;
            end if;
            if Run_Cmd (Ctl, "enable", Unit, "") /= 0 then
               Put_Line (Standard_Error, "ERR: systemctl enable failed");
               return;
            end if;
            if Run_Cmd (Ctl, "start", Unit, "") /= 0 then
               Put_Line (Standard_Error, "ERR: systemctl start failed");
               return;
            end if;
         end;
         Put_Line ("installed system unit " & Unit & " for " & Dst);
         Put_Line ("note: runs at boot as root; unit file holds "
                   & "the account password (mode 600).");
         return;
      end if;
      if Home = "" then
         Put_Line (Standard_Error, "ERR: HOME not set");
         return;
      end if;
      Write_Unit_File (Unit_Dir, "default.target");
      declare
         Ctl : constant String := Which ("systemctl");
      begin
         if Ctl = "" then
            Put_Line (Standard_Error,
              "ERR: systemctl not found; unit file kept at "
              & Ada.Directories.Compose (Unit_Dir, Unit));
            return;
         end if;
         if Run_Cmd (Ctl, "--user", "daemon-reload", "") /= 0 then
            Put_Line (Standard_Error,
              "ERR: systemctl --user failed (no user bus; if root use "
              & "is intended this should have taken the system path; "
              & "unit file kept)");
            return;
         end if;
         if Run_Cmd (Ctl, "--user", "enable", Unit) /= 0 then
            Put_Line (Standard_Error, "ERR: systemctl enable failed");
            return;
         end if;
         if Run_Cmd (Ctl, "--user", "start", Unit) /= 0 then
            Put_Line (Standard_Error, "ERR: systemctl start failed");
            return;
         end if;
      end;
      Put_Line ("installed " & Unit & " for " & Dst);
      Put_Line ("note: 'loginctl enable-linger "
                & Ada.Environment_Variables.Value ("USER", "$USER")
                & "' keeps it running after logout;");
      Put_Line ("note: unit file holds the account password (mode 600).");
   exception
      when others =>
         Put_Line (Standard_Error, "ERR: install failed");
   end Do_Install_Service;

   procedure Do_Uninstall_Service is
      use Ada.Text_IO;
      Dev : constant String := To_String (Dev_Id);
      Home : constant String :=
        Ada.Environment_Variables.Value ("HOME", "");
      Unit : constant String := Unit_Name_Of (Dev);
      P    : Unbounded_String;
      Run_Cmd_Discard : Integer;
      pragma Unreferenced (Run_Cmd_Discard);
   begin
      if not Safe_Dev_Name (Dev) then
         Put_Line (Standard_Error, "ERR: need --name <id> of the service");
         return;
      end if;
      if C_Geteuid = 0 then
         Run_Cmd_Discard := Run_Cmd (Which ("systemctl"), "stop", Unit, "");
         Run_Cmd_Discard := Run_Cmd (Which ("systemctl"), "disable", Unit, "");
         P := To_Unbounded_String
           (Ada.Directories.Compose ("/etc/systemd/system", Unit));
      else
         if Home = "" then
            Put_Line (Standard_Error, "ERR: HOME not set");
            return;
         end if;
         Run_Cmd_Discard := Run_Cmd (Which ("systemctl"), "--user", "stop", Unit);
         Run_Cmd_Discard :=
           Run_Cmd (Which ("systemctl"), "--user", "disable", Unit);
         P := To_Unbounded_String
           (Ada.Directories.Compose (Unit_Dir, Unit));
      end if;
      if Ada.Directories.Exists (To_String (P)) then
         Ada.Directories.Delete_File (To_String (P));
         Put_Line ("removed " & Unit);
      else
         Put_Line ("no unit file " & Unit);
      end if;
   exception
      when others =>
         Put_Line (Standard_Error, "ERR: uninstall failed");
   end Do_Uninstall_Service;

   procedure Do_Self_Uninstall is
      --  Self-removal after the server ordered removal ("REMOVED").
      --  Fixed: Restart=always restarts on clean exit even when disabled,
      --  so disable alone is NOT enough (old comment was wrong). Order is
      --  disable -> delete file -> daemon-reload (after delete, else unit
      --  stays loaded as 'bad') -> stop last. Stop SIGTERMs ourselves but
      --  work is already done; systemd then marks inactive and cancels
      --  the restart job. Root uses system units, others use --user.
      use Ada.Text_IO;
      Dev  : constant String := To_String (Dev_Id);
      P    : Unbounded_String;
      Rc   : Integer;
      Ctl  : constant String := Which ("systemctl");
      pragma Unreferenced (Rc);
   begin
      if Dev = "" or else not Safe_Dev_Name (Dev) then
         return;
      end if;
      if Ctl = "" then
         return;
      end if;
      if C_Geteuid = 0 then
         P := To_Unbounded_String
           (Ada.Directories.Compose
              ("/etc/systemd/system", Unit_Name_Of (Dev)));
         Rc := Run_Cmd (Ctl, "disable", Unit_Name_Of (Dev));
         if Ada.Directories.Exists (To_String (P)) then
            begin
               Ada.Directories.Delete_File (To_String (P));
            exception
               when others => null;
            end;
         end if;
         Rc := Run_Cmd (Ctl, "daemon-reload", "", "");
         Put_Line ("removed " & Unit_Name_Of (Dev)
                   & " (device removed by manager)");
         Rc := Run_Cmd (Ctl, "stop", Unit_Name_Of (Dev));
      else
         P := To_Unbounded_String
           (Ada.Directories.Compose (Unit_Dir, Unit_Name_Of (Dev)));
         Rc := Run_Cmd (Ctl, "--user", "disable", Unit_Name_Of (Dev));
         if Ada.Directories.Exists (To_String (P)) then
            begin
               Ada.Directories.Delete_File (To_String (P));
            exception
               when others => null;
            end;
         end if;
         Rc := Run_Cmd (Ctl, "--user", "daemon-reload", "", "");
         Put_Line ("removed " & Unit_Name_Of (Dev)
                   & " (device removed by manager)");
         Rc := Run_Cmd (Ctl, "--user", "stop", Unit_Name_Of (Dev));
      end if;
   exception
      when others => null;
   end Do_Self_Uninstall;

begin
   Ignore_Sigpipe;
   declare
      use Ada.Command_Line;
      I : Natural := 1;
      Got_Mode : Boolean := False;
   begin
      while I <= Argument_Count loop
         declare
            A : constant String := Argument (I);
         begin
            if A = "-s" and then I < Argument_Count then
               Host := To_Unbounded_String (Argument (I + 1));
               I := I + 2;
            elsif A = "-p" and then I < Argument_Count then
               Port := Integer'Value (Argument (I + 1));
               I := I + 2;
            elsif A = "--ws" and then I < Argument_Count then
               Ws_Url := To_Unbounded_String (Argument (I + 1));
               I := I + 2;
            elsif A = "-u" and then I + 1 <= Argument_Count then
               Is_Dev := False;
               User := To_Unbounded_String (Argument (I + 1));
               Pass := To_Unbounded_String (Argument (I + 2));
               Got_Mode := True;
               I := I + 3;
            elsif A = "-c" and then I + 1 <= Argument_Count then
               Is_Dev := True;
               User := To_Unbounded_String (Argument (I + 1));
               Pass := To_Unbounded_String (Argument (I + 2));
               Got_Mode := True;
               I := I + 3;
            elsif A = "--name" and then I < Argument_Count then
               Dev_Id := To_Unbounded_String (Argument (I + 1));
               Name_Given := True;
               I := I + 2;
            elsif A = "-r" then
               Do_Install := True;
               I := I + 1;
            elsif A = "--persist" then
               Persist := True;
               I := I + 1;
            elsif A = "--uninstall" then
               Do_Uninstall := True;
               I := I + 1;
            else
               Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
                 "usage: client [-s host] [-p port] [--ws ws[s]://host[:port][/path]]"
                 & " -u|-c user password-or-key [--name id] [-r] [--persist] [--uninstall]");
               return;
            end if;
         end;
      end loop;
      if not Got_Mode and not Do_Uninstall then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "usage: client [-s host] [-p port] [--ws ws[s]://host[:port][/path]]"
           & " -u|-c user password-or-key [--name id] [-r] [--persist] [--uninstall]");
         return;
      end if;
   exception
      when Constraint_Error =>
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "bad argument");
         return;
   end;
   if Port not in 1 .. 65_535 then
      Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "bad port");
      return;
   end if;
   if Do_Uninstall then
      if not Name_Given then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "uninstall needs --name <device id>");
         return;
      end if;
      Do_Uninstall_Service;
      return;
   end if;
   if Do_Install then
      if not Is_Dev then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "-r needs device mode (-c user password --name id)");
         return;
      end if;
      if not Name_Given then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "-r needs an explicit --name <device id>");
         return;
      end if;
      Do_Install_Service;
      return;
   end if;
   if Is_Dev then
      if Length (Dev_Id) = 0 then
         Dev_Id := To_Unbounded_String ("dev-" & Rand_Hex (2));
      end if;
      Device_Loop (To_String (User), To_String (Pass), To_String (Dev_Id));
      if Was_Removed then
         Do_Self_Uninstall;
         GNAT.OS_Lib.OS_Exit (0);
      end if;
   else
      Manager_Loop (To_String (User), To_String (Pass));
   end if;
end Client;
